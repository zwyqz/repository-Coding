/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50534
Source Host           : 127.0.0.1:3306
Source Database       : qhl1

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2014-06-18 12:11:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `sname` varchar(10) NOT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `name` varchar(200) DEFAULT NULL,
  `option1` varchar(200) DEFAULT NULL,
  `answer` varchar(4) DEFAULT NULL,
  `grade` varchar(6) DEFAULT NULL,
  `score` varchar(2) DEFAULT NULL,
  `num` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for student1
-- ----------------------------
DROP TABLE IF EXISTS `student1`;
CREATE TABLE `student1` (
  `sname` varchar(10) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `mail` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for suggest
-- ----------------------------
DROP TABLE IF EXISTS `suggest`;
CREATE TABLE `suggest` (
  `sno` varchar(10) DEFAULT NULL,
  `advise` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `sname` varchar(10) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `mail` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
