/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50534
Source Host           : 127.0.0.1:3306
Source Database       : qhl1

Target Server Type    : MYSQL
Target Server Version : 50534
File Encoding         : 65001

Date: 2014-06-18 12:05:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for manager
-- ----------------------------
DROP TABLE IF EXISTS `manager`;
CREATE TABLE `manager` (
  `sname` varchar(10) NOT NULL,
  `sex` varchar(4) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of manager
-- ----------------------------
INSERT INTO `manager` VALUES ('20109999', '男', '32', '111');

-- ----------------------------
-- Table structure for question
-- ----------------------------
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
  `name` varchar(200) DEFAULT NULL,
  `option1` varchar(200) DEFAULT NULL,
  `answer` varchar(4) DEFAULT NULL,
  `grade` varchar(6) DEFAULT NULL,
  `score` varchar(2) DEFAULT NULL,
  `num` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of question
-- ----------------------------
INSERT INTO `question` VALUES ('煎煮中药时不宜选择下列那种器具：', 'A、砂锅B、不发噶司法fgggg锈钢锅C、铁锅', 'C', '二级', '3', '4');
INSERT INTO `question` VALUES ('下列内容不属于药品说明书内容的是：', 'A、药方法品名称B、用法用量C、药品价格', 'C', '一级', '2', '5');
INSERT INTO `question` VALUES ('药品包装必须按照规定印有或者贴有标签并附有：', 'A、赠品B、说明书C、使用证明', 'B', '二级', '2', '6');
INSERT INTO `question` VALUES ('如果电器着火，哪一种灭火器不能用？', 'A、二氧化碳B、1211C、泡沫灭火器', 'C', '二级', '4', '3');
INSERT INTO `question` VALUES ('字眼日是每年的：', 'A、5月5日B、6月6日C、7月7日', 'B', '一级', '8', '7');
INSERT INTO `question` VALUES ('扑救电器火灾应首先做什么？', 'A、切断电源B、灭火C、泼水', 'A', '二级', '6', '1');
INSERT INTO `question` VALUES ('灭火器使用时的安全距离约多少米合适？', 'A、1-1.5米；B、3米；C、5米', 'B', '二级', '4', '8');
INSERT INTO `question` VALUES ('目前我国通用的火灾报警电话是哪个号码？', 'A、110B、120C、119', 'C', '二级', '2', '9');
INSERT INTO `question` VALUES ('全国“119”消防宣传日是每年的几月几号？', 'A、1月19日B、9月11日C、11月9日', 'C', '二级', '3', '10');
INSERT INTO `question` VALUES ('可以用水扑灭的火灾是下列哪种物质？', 'A、油类起火B、酒精起火C、棉被起火', 'C', '一级', '4', '11');
INSERT INTO `question` VALUES ('楼内失火应', 'A 从疏散通道逃离B 乘坐电梯逃离C 在现场看热闹', 'A', '一级', '5', '12');
INSERT INTO `question` VALUES ('当遇到火灾时，要迅速向', 'A着火相反的方向B人员多的方向C 安全出口的方向', 'C', '一级', '2', '13');
INSERT INTO `question` VALUES ('带电物体火灾时，不能选用下列哪种灭火器？', 'A、二氧化碳灭火器B、清水泡沫灭火器C、干粉灭火器', 'B', '一级', '6', '2');

-- ----------------------------
-- Table structure for student1
-- ----------------------------
DROP TABLE IF EXISTS `student1`;
CREATE TABLE `student1` (
  `sname` varchar(10) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `mail` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student1
-- ----------------------------
INSERT INTO `student1` VALUES ('20101901', '1111', '男', '22', '1222232@qq.com');
INSERT INTO `student1` VALUES ('20101902', '124', '男', '23', '552562@qq.com');

-- ----------------------------
-- Table structure for suggest
-- ----------------------------
DROP TABLE IF EXISTS `suggest`;
CREATE TABLE `suggest` (
  `sno` varchar(10) DEFAULT NULL,
  `advise` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of suggest
-- ----------------------------
INSERT INTO `suggest` VALUES ('1', '发生法');
INSERT INTO `suggest` VALUES ('3', '干啥哈哈');
INSERT INTO `suggest` VALUES ('2', '双方将卡收费');
INSERT INTO `suggest` VALUES ('4', '按合同热腾腾');

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `sname` varchar(10) NOT NULL,
  `password` varchar(20) DEFAULT NULL,
  `sex` varchar(6) DEFAULT NULL,
  `age` varchar(4) DEFAULT NULL,
  `mail` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`sname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of teacher
-- ----------------------------
INSERT INTO `teacher` VALUES ('20101966', '3331', '男', '32', '222@qq.com');
INSERT INTO `teacher` VALUES ('20101988', '888', '女', '33', '22189@qq.com');
