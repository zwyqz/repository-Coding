package javaclass;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import java.util.Vector;
import java.sql.Statement;

import javaclass.customer;
import javaclass.question;










import com.mysql.jdbc.*;
public class Sql {
	private Connection connection;
	private static String url = "jdbc:mysql://localhost:3306/qhl1";
	private static String user = "root";
	private static String password = "2010";
	public Sql()
	{
		String driverClassName = "com.mysql.jdbc.Driver";
		try
		  {
		   Class.forName(driverClassName);
		   if (connection == null || connection.isClosed())
		    connection = DriverManager.getConnection( url, user,password);
	       System.out.println("k1k1k1");
		  }
		  catch (ClassNotFoundException ex)
		  {
			  ex.printStackTrace();
		
		  }
		  catch(SQLException e)
		  {
			e.printStackTrace();  
	
		  }
		 
	}
	public void inserttables(String sname,String psw,String sex,String age,String mail)
	{
		try{
			
			PreparedStatement UserQuery = connection.prepareStatement("insert into student1(sname,password,sex,age,mail) values(?,?,?,?,?)");
			UserQuery.setString(1,sname);
			UserQuery.setString(2,psw);
			UserQuery.setString(3,sex);
			
			UserQuery.setString(4,age);
			UserQuery.setString(5,mail);
			
			UserQuery.executeUpdate();
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	     }
	} 
	public void inserttablet(String sname,String psw,String sex,String age,String mail)
	{
		try{
			
			PreparedStatement UserQuery = connection.prepareStatement("insert into teacher(sname,password,sex,age,mail) values(?,?,?,?,?)");
			UserQuery.setString(1,sname);
			UserQuery.setString(2,psw);
			UserQuery.setString(3,sex);
			
			UserQuery.setString(4,age);
			UserQuery.setString(5,mail);
			
			UserQuery.executeUpdate();
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	     }
	} 
	public String Selectsnames(String sname)
	{
		String worth = "0";
		System.out.println("gggggg");
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 ;");
			
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next()){
				worth = result.getString("sname");
			 if(worth.trim().equals(sname.trim()))
			 {
				worth="1";
				return worth;
			 }
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return worth;
	}
	public String Selectsnamet(String sname)
	{
		String worth = "0";
		
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher ;");
			
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next()){
				worth = result.getString("sname");
			 if(worth.trim().equals(sname.trim()))
			 {
				worth="1";
				return worth;
			 }
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return worth;
	}
	public String Selectsnamem(String sname)
	{
		String worth = "0";
		
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from manager ;");
			
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next()){
				worth = result.getString("sname");
			 if(worth.trim().equals(sname.trim()))
			 {
				worth="1";
				return worth;
			 }
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return worth;
	}
	
	public String Selectpwds(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("password");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectpwdt(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher where sname  = ?");
			
			UserQuery.setString(1,sname);
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("password");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectpwdg(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from manager where sname  = ?");
			
			UserQuery.setString(1,sname);
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("password");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public void updatattables(String sname,String psw)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update student1 set password=? where sname=?;");
			UserQuery.setString(1,psw);
			UserQuery.setString(2,sname);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void updatattablet(String sname,String psw)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update teacher set password=? where sname=?;");
			UserQuery.setString(1,psw);
			UserQuery.setString(2,sname);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}	
	public void updatattableg(String sname,String psw)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update manager set password=? where sname=?;");
			UserQuery.setString(1,psw);
			UserQuery.setString(2,sname);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}	
	public String Selectsexs(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("sex");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectsext(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("sex");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectsexg(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from manager where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("sex");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectages(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("age");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectaget(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("age");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectageg(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from manager where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("age");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectmails(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("mail");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public String Selectmailt(String sname)
	{
		String pwd = null;
		try {
			 
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher where sname  = ?");
			
			UserQuery.setString(1,sname);		
			ResultSet result = UserQuery.executeQuery();
			
		
			while (result.next())
				pwd = result.getString("mail");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pwd;
	}
	public void Selectstu()
	{
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from student1 ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				worth = result.getString("sname");
				if(!worth.equals(""))
				{
			     customer.v.add(worth.trim());
				}
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void Selectteach()
	{
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from teacher ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				worth = result.getString("sname");
				if(!worth.equals(""))
				{
			     customer.v.add(worth.trim());
				}
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void dettables(String sname)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("delete from student1 where sname=?");
			UserQuery.setString(1,sname);
			UserQuery.executeUpdate();
			System.out.println("999999");
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void dettablet(String sname)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("delete from teacher where sname=?");
			UserQuery.setString(1,sname);
			UserQuery.executeUpdate();
			System.out.println("88888");
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public int Selectnum()
	{
		int n=0;
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question ");
			ResultSet result = UserQuery.executeQuery();
			while (result.next()){
				worth = result.getString("name");
				n=n+1;
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return n;
	}
	public int Selectnumop()
	{
		int n=0;
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from suggest ");
			ResultSet result = UserQuery.executeQuery();
			while (result.next()){
				worth = result.getString("sno");
				n=n+1;
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return n;
	}
	public int Selectnum1()
	{
		int n=0;
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where grade='һ��'");
			ResultSet result = UserQuery.executeQuery();
			while (result.next()){
				worth = result.getString("name");
				n=n+1;
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return n;
	}
	public int Selectnum2()
	{
		int n=0;
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where grade='����'");
			ResultSet result = UserQuery.executeQuery();
			while (result.next()){
				worth = result.getString("name");
				n=n+1;
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return n;
	}
	
	public void inserttableQ(String name,String option,String answer,String grade,String score,String num)
	{
		try{
			
			PreparedStatement UserQuery = connection.prepareStatement("insert into question(name,option1,answer,grade,score,num) values(?,?,?,?,?,?);");
			UserQuery.setString(1,name);
			UserQuery.setString(2,option);
			UserQuery.setString(3,answer);
			UserQuery.setString(4,grade);
			UserQuery.setString(5,score);
			UserQuery.setString(6,num);
			UserQuery.executeUpdate();
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	     }
	}
	public void insertsug(String sno,String advise)
	{
		try{
			
			PreparedStatement UserQuery = connection.prepareStatement("insert into suggest(sno,advise) values(?,?);");
			UserQuery.setString(1,sno);
			UserQuery.setString(2,advise);
			
			UserQuery.executeUpdate();
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	     }
	}
	public void Selectquestion1()
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where grade='һ��' ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
			    worth = result.getString("num");
			    que.setNum(worth);
			     customer.v.add(que);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void Selectquestion2()
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where grade='����' ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
			    worth = result.getString("num");
			    que.setNum(worth);
			     customer.v.add(que);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void Selectquestion()
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question  ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
			    worth = result.getString("num");
			    que.setNum(worth);
			     customer.v.add(que);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void searchquestion(String sou)
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where name like '"+sou+"%' ");
			//UserQuery.setString(1,sou);
			System.out.println(sou);
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
				
			     customer.v.add(que);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void deletques(String num)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("delete from question where num=?");
			UserQuery.setString(1,num);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void updatanum(String num,String num1)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update question set num=? where num=?;");
		
			UserQuery.setString(1,num);
			UserQuery.setString(2,num1);
			
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void Selectque(String num)
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where num=? ");
			UserQuery.setString(1,num);
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
			    worth = result.getString("num");
			    que.setNum(worth);
			    worth = result.getString("grade");
			    que.setgrade(worth);
			     customer.v.add(que);
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	public void updatquestion(String option1,String answer,String grade,String score,String num)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update question set option1=?,answer=?,grade=?,score=? where num=?;");
		
			UserQuery.setString(1,option1);
			UserQuery.setString(2,answer);
			UserQuery.setString(3,grade);
			UserQuery.setString(4,score);
			UserQuery.setString(5,num);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void randomquestion()
	{
		
		try {
			for(int i = 0 ; i < customer.m.size() ; i++ ){
				String m=(String)customer.m.get(i);
				System.out.println(m);
				System.out.println("vvvvvvvvvvvv");
			String worth = null;
			PreparedStatement UserQuery = connection.prepareStatement("select * from question where num="+m+" ");
			ResultSet result = UserQuery.executeQuery();
			
			while (result.next()){
				question que=new question();
				worth = result.getString("name");
			    que.setName(worth);
			    worth = result.getString("option1");
			    que.setOption1(worth);
			    worth = result.getString("answer");
			    que.setAnswer(worth);
			    customer.k.add(worth);
			    worth = result.getString("score");
			    que.setScore(worth);
			    customer.s.add(worth);
			    worth = result.getString("num");
			    que.setNum(worth);
			     customer.vv.add(que);
				
			}
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
		}
	
	public void Selectsugg()
	{
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from suggest ");
			ResultSet result = UserQuery.executeQuery();
			customer.v.clear();
			while (result.next()){
				worth = result.getString("sno");
				if(!worth.equals(""))
				{
			     customer.v.add(worth.trim());
				}
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}
	
	public String Selectsuggest(String sno)
	{
		
		String worth = null;
		try {
			PreparedStatement UserQuery = connection.prepareStatement("select * from suggest where sno=?");
			UserQuery.setString(1,sno);
			ResultSet result = UserQuery.executeQuery();
			while (result.next()){
				worth = result.getString("advise");
				
			}
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return worth;
	}
	public void deletsugg(String sno)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("delete from suggest where sno=?");
			UserQuery.setString(1,sno);
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
	public void updatasugg(String sno,String sno1)
	{
		try{
			PreparedStatement UserQuery = connection.prepareStatement("update suggest set sno=? where sno=?;");
		
			UserQuery.setString(1,sno);
			UserQuery.setString(2,sno1);
			
			UserQuery.executeUpdate();
			
		
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	}
	}
}
