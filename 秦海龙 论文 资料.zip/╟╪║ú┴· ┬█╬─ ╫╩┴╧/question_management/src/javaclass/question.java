package javaclass;

public class question {
	 
	private String name;
	private  String option1;
     private  String answer;
     private  String score;
     private  String num;
     private  String grade;
     
     public String getgrade() {
  		return grade;
  	}
  	public void setgrade(String grade) {
  		this.grade = grade;
  	}
     public String getNum() {
 		return num;
 	}
 	public void setNum(String num) {
 		this.num = num;
 	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOption1() {
		return option1;
	}
	public void setOption1(String option1) {
		this.option1 = option1;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
     
}
