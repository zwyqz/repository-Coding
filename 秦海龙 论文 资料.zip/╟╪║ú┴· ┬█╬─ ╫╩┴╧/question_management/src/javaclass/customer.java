package javaclass;

import java.util.Vector;

public class customer {
     public static String name;
     public static String psw;
     public static String work;
     public static Vector v = new Vector();
     public static Vector m = new Vector();
     public static Vector k = new Vector();
     public static Vector s = new Vector();
     public static Vector vv = new Vector();
}
