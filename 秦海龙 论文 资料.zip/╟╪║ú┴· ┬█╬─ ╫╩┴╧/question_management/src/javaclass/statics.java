package javaclass;

public class statics {
	public static int zhu=0;
	public static int login=0;
	public static int xiu=0;
	public static int work=0;
	public static int work1=0;
	public static int biao=0;
	public static int name=0;
	public static String num="0";
	public static String su="0";
	public static int op=0;

}
