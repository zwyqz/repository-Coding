package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaclass.Sql;
import javaclass.customer;
import javaclass.statics;
/**
 * Servlet implementation class loginservlet
 */
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("2221111");
		request.setCharacterEncoding("utf-8");
		String name=(String)request.getParameter("name");
		String psw=(String)request.getParameter("psw");
		String work=(String)request.getParameter("work");
		Sql sql=new Sql();
		System.out.println("0000");	
		System.out.println(work);
		System.out.println(name);
		System.out.println("30033");	
	    	customer.name=name;
	    	customer.work=work;
	    	
	    	if(work.trim().equals("ѧ��"))
	    	{
	    		 System.out.println(sql.Selectsnames(name.trim()));
	    		 if(sql.Selectsnames(name.trim()).trim().equals("1"))
	    		 {
	    			 System.out.println("fffffff");
	    		  if(sql.Selectpwds(name.trim()).equals(psw.trim()))
	    		  {
	    		 	customer.psw=psw.trim();
	    		    response.sendRedirect("/question_management/login.jsp");
	    		  }
	    		  else
	    		    {
	    		    	statics.login=1;
	    		    	response.sendRedirect("/question_management/main.jsp");
	    		    }
	    		 }
	    		 else
	    		 {
	    			    statics.name=1;
						response.sendRedirect("/question_management/main.jsp");
					
	    		 }
	    	}
	    	else{
	    		
	    		if(work.trim().equals("��ʦ"))
	    		{
	    			if(sql.Selectsnamet(name.trim()).trim()=="1")
		    		 {
	    			if(sql.Selectpwdt(name.trim()).equals(psw))
	    			{
	    				customer.psw=psw.trim();
	    	    		response.sendRedirect("/question_management/login2.jsp");
	    			}
	    	    		 else
	    	    		    {
	    	    		    	statics.login=1;
	    	    		    	response.sendRedirect("/question_management/main.jsp");
	    	    		    }
		    		 }
		    		 else
		    		 {
		    			    statics.name=1;
							response.sendRedirect("/question_management/main.jsp");
						
		    		 }
	    			
	    		}
	    		else{
	    			if(sql.Selectsnamem(name.trim()).trim()=="1")
		    		 {
	    			if(sql.Selectpwdg(name.trim()).equals(psw))
	    			{
	    				customer.psw=psw.trim();
	    	    		response.sendRedirect("/question_management/login3.jsp");
	    			}
	    	    		 else
	    	    		    {
	    	    		    	statics.login=1;
	    	    		    	response.sendRedirect("/question_management/main.jsp");
	    	    		    }
		    		 }
		    		 else
		    		 {
		    			    statics.name=1;
							response.sendRedirect("/question_management/main.jsp");
						
		    		 }
	    		}
	    	}
	  
	   
		
		
	}

}
