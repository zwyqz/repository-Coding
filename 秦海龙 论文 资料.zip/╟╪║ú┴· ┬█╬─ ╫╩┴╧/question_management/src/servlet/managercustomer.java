package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaclass.Sql;
import javaclass.statics;
/**
 * Servlet implementation class managercustomer
 */
public class managercustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public managercustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String sou=(String)request.getParameter("sou");
		Sql sql=new Sql();
		if(statics.work1==3)
		{
			statics.work=3;
			sql.dettables(sou.trim());
			response.sendRedirect("/question_management/customer.jsp");
		}
		if(statics.work1==4)
		{
			statics.work=4;
			sql.dettablet(sou.trim());
			response.sendRedirect("/question_management/customer.jsp");
		}
		
	}

}
