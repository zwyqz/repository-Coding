package servlet;

import java.io.IOException;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaclass.customer;
import javaclass.statics;
import javaclass.Sql;
/**
 * Servlet implementation class randomservlet
 */
public class randomservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public randomservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String nan=(String)request.getParameter("nan");
		Sql sql=new Sql();
		Random rd1 = new Random();
		int n=sql.Selectnum();
		customer.m.clear();
		customer.v.clear();
		customer.k.clear();
		customer.s.clear();
		customer.vv.clear();
		 for (int i = 0; i < 5; i++) {
				// Random��nextInt(int n)��������һ��[0, n)��Χ�ڵ������
			int m=rd1.nextInt(n)+1;
			String mm=String.valueOf(m);
			System.out.println(mm);
			customer.m.add(mm);
			}
           sql.randomquestion();
           response.sendRedirect("/question_management/text.jsp"); 
			
		
		
	}

}
