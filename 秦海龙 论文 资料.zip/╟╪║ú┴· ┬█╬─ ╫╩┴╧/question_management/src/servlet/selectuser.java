package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javaclass.Sql;

/**
 * Servlet implementation class selectuser
 */
public class selectuser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public selectuser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String customer=(String)request.getParameter("customer");
		
		System.out.println("999999999999");
	   if(customer.equals("1"))
	   {
		   javaclass.statics.work=1;
		   response.sendRedirect("/question_management/lookalluser.jsp");
	   }
	   if(customer.equals("2"))
	   {
		   javaclass.statics.work=2;
		   response.sendRedirect("/question_management/lookalluser.jsp");
	   }
	   if(customer.equals("3"))
	   {
		   javaclass.statics.work=3;
		   response.sendRedirect("/question_management/customer.jsp");
	   }
	   if(customer.equals("4"))
	   {
		   javaclass.statics.work=4;
		   response.sendRedirect("/question_management/customer.jsp");
	   }
	   if(customer.equals("5"))
	   {
		   javaclass.statics.work=5;
		   response.sendRedirect("/question_management/lookquestion.jsp");
	   }
	   if(customer.equals("6"))
	   {
		   javaclass.statics.work=6;
		   response.sendRedirect("/question_management/lookquestion.jsp");
	   }
	   if(customer.equals("7"))
	   {
		   javaclass.statics.work=7;
		   response.sendRedirect("/question_management/managerquestion.jsp");
	   }
	   if(customer.equals("8"))
	   {
		   javaclass.statics.work=8;
		   response.sendRedirect("/question_management/managerquestion.jsp");
	   }
	   if(customer.equals("9"))
	   {
		   javaclass.statics.work=9;
		   response.sendRedirect("/question_management/manageropinion.jsp");
	   }
	}

}
