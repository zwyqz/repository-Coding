package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javaclass.statics;
import javaclass.Sql;
/**
 * Servlet implementation class zhuceservlet
 */
public class zhuceservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public zhuceservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String name1=(String)request.getParameter("name1");
		String psw1=(String)request.getParameter("psw1");
		String psw2=(String)request.getParameter("psw2");
		String sex=(String)request.getParameter("sex");
		String work=(String)request.getParameter("work");
		String age=(String)request.getParameter("age");
		String box=(String)request.getParameter("box");
		String change=(String)request.getParameter("change");
		String change1=(String)request.getSession().getAttribute("valcode");
		System.out.println(change);
		System.out.println(work);
		System.out.println(request.getSession().getAttribute("valcode"));
		Sql sql=new Sql();
		
		if(name1.trim().equals("")||psw1.trim().equals("")|psw2.trim().equals("")||age.trim().equals("")||box.trim().equals(""))
		{
			statics.zhu=1;
			response.sendRedirect("/question_management/zhuce.jsp");
			
		}
		else{
			if(!psw1.trim().equals(psw2))
			{
				statics.zhu=1;
				response.sendRedirect("/question_management/zhuce.jsp");
			}
			else{
			
			if(!change.trim().equals(change1))
				   {
					statics.zhu=2;
					response.sendRedirect("/question_management/zhuce.jsp");
				   }
			else{
			if(work.trim().equals("��ʦ"))
			{
				System.out.println("12222222");
				if(sql.Selectsnamet(name1).trim()!="1")
				{
					sql.inserttablet(name1, psw1, sex, age, box);
					response.sendRedirect("/question_management/main.jsp");
				}
					else{
						statics.zhu=3;
						response.sendRedirect("/question_management/zhuce.jsp");
					}
			}
			if(work.trim().equals("ѧ��"))
			{
				System.out.println("133333333");
				if(sql.Selectsnames(name1).trim()!="1"){
				sql.inserttables(name1, psw1, sex, age, box);
				response.sendRedirect("/question_management/main.jsp");
				}
				else{
					statics.zhu=3;
					response.sendRedirect("/question_management/zhuce.jsp");
				}
				
			}
			}
			}
		}
		
	}

}
