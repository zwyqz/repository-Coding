package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javaclass.Sql;
import javaclass.customer;
import javaclass.statics;
/**
 * Servlet implementation class questionservlet
 */
public class questionservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public questionservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String wen=(String)request.getParameter("wen");
		String xuan=(String)request.getParameter("xuan");
		String da=(String)request.getParameter("da");
		String dj=(String)request.getParameter("dj");
		String fen=(String)request.getParameter("fen");
		if(wen.trim().equals("")||xuan.trim().equals("")||fen.trim().equals(""))
		{
			statics.biao=8;
			response.sendRedirect("/question_management/loginquestion.jsp");
		}
		else{
		Sql sql=new Sql();
		System.out.println(wen);
		System.out.println(dj);
		int m=sql.Selectnum();
		  m=m+1;
		String s=String.valueOf(m);
		sql.inserttableQ(wen.trim(), xuan.trim(), da.trim(), dj.trim(), fen.trim(), s.trim());
		statics.biao=1;
		response.sendRedirect("/question_management/loginquestion.jsp");
		}
		
	}

}
