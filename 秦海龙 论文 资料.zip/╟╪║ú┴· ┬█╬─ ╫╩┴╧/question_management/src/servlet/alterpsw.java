package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sound.midi.SysexMessage;
import javaclass.customer;
import javaclass.statics;
import javaclass.Sql;
/**
 * Servlet implementation class alterpsw
 */
public class alterpsw extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public alterpsw() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String psw3=(String)request.getParameter("psw3");
		String psw4=(String)request.getParameter("psw4");
		String psw5=(String)request.getParameter("psw5");
		System.out.println(psw3);
		System.out.println(customer.psw);
		System.out.println(customer.name);
		System.out.println(customer.work);
		Sql sql1=new Sql();
		if(psw4.trim().equals(psw5.trim()))
		{
		  if(psw3.trim().equals(customer.psw))
		  {
			  if(customer.work.equals("ѧ��"))
			  {
			    sql1.updatattables(customer.name, psw4.trim());
			    customer.psw=psw4.trim();
			    statics.xiu=3;
			    response.sendRedirect("/question_management/newpsw.jsp");
			  }
			  else{
				  if(customer.work.equals("��ʦ"))
				  {
					  sql1.updatattablet(customer.name, psw4.trim());
					  customer.psw=psw4.trim();
					  statics.xiu=3;
					    response.sendRedirect("/question_management/newpsw.jsp");
				  }
				  else{
					  sql1.updatattableg(customer.name, psw4.trim());
					  customer.psw=psw4.trim();
					  statics.xiu=3;
					    response.sendRedirect("/question_management/newpsw.jsp");
				  }
			  }
		  }
		 else {
			statics.xiu=1;
		 	response.sendRedirect("/question_management/newpsw.jsp");
		  }
		}
		else{
			statics.xiu=2;
			response.sendRedirect("/question_management/newpsw.jsp");
		}
	}

}
