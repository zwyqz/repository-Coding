package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javaclass.customer;
import javaclass.statics;
import javaclass.Sql;
/**
 * Servlet implementation class answerservlet
 */
public class answerservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public answerservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String da1=(String)request.getParameter("da1");
		String da2=(String)request.getParameter("da2");
		String da3=(String)request.getParameter("da3");
		String da4=(String)request.getParameter("da4");
		String da5=(String)request.getParameter("da5");
		customer.v.clear();
		
		customer.v.add(da1);
		customer.v.add(da2);
		customer.v.add(da3);
		customer.v.add(da4);
		customer.v.add(da5);
		int sum=0;
		System.out.println(customer.k.size()+".��������"+customer.v.size());
		for(int i = 0 ; i < customer.k.size() ; i++ ){
			String m=(String)customer.k.get(i);
			
			String c=(String)customer.v.get(i);
			if(c.equals(m))
			{
				String n=(String)customer.s.get(i);
				int nn=Integer.parseInt(n);
				sum=sum+nn;
			}
			
		}
		String su=String.valueOf(sum);
		statics.su=su;
		System.out.println("qqqqqqqq");
		System.out.println(su);
		 response.sendRedirect("/question_management/success.jsp"); 
		
	}

}
