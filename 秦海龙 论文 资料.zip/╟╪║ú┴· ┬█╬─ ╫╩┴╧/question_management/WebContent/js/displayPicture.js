﻿// JavaScript Document
/*图片变换脚本*/
$(document).ready(
 function()
 {
	 $("#mlm1").mouseover(
	 function(){
		 $("#middle-left-top1").css("background-image","url('./images/big_1.png')");
		 $("#mlm1").css("border","#F00 1px solid");
		 $("#mlm2").css("border","#999 1px solid");
		 $("#mlm3").css("border","#999 1px solid");
		 $("#mlm4").css("border","#999 1px solid");
		 })
	 });
$(document).ready(
 function()
 {
	 $("#mlm2").mouseover(
	 function(){
		 $("#middle-left-top1").css("background-image","url('./images/big_2.png')");        $("#mlm1").css("border","#999 1px solid");
		 $("#mlm2").css("border","#F00 1px solid");
		 $("#mlm3").css("border","#999 1px solid");
		 $("#mlm4").css("border","#999 1px solid");
		 })
	 });
$(document).ready(
 function()
 {
	 $("#mlm3").mouseover(
	 function(){
		 $("#middle-left-top1").css("background-image","url('./images/big_3.png')");
		 $("#mlm1").css("border","#999 1px solid");
		 $("#mlm2").css("border","#999 1px solid");
		 $("#mlm3").css("border","#F00 1px solid");
		 $("#mlm4").css("border","#999 1px solid");
		 })
	 });
$(document).ready(
 function()
 {
	 $("#mlm4").mouseover(
	 function(){
		 $("#middle-left-top1").css("background-image","url('./images/big_4.png')");
		 $("#mlm1").css("border","#999 1px solid");
		 $("#mlm2").css("border","#999 1px solid");
		 $("#mlm3").css("border","#999 1px solid");
		 $("#mlm4").css("border","#F00 1px solid");
		 })
	 });
/*图片变换脚本*/
/*输入框脚本*/
$(document).ready(
     function()
	 {
	 $("#top-search1").focus(
	  function()
	  {
		  document.getElementById("top-search1").value="";
		  })
	});
$(document).ready(
     function()
	 {
	 $("#top-search1").blur(
	  function()
	  {
		  if((document.getElementById("top-search1").value)=="")
		  {
			  document.getElementById("top-search1").value="请输入下图看到的字符 ";
			  }
		  
		  })
	});
/*输入框脚本*/
/*固定框的脚本*/
$(document).ready(function()
{
	$(window).scroll(function()
	{
		if($(document).scrollTop()!=0)
	{
		
		
		document.getElementById("returnTop1").style.display="block";
		document.getElementById("questionnaire1").style.display="block";
		document.getElementById("merchant1").style.display="block";
		}
	else
	{
		
		document.getElementById("returnTop1").style.display="none";
		document.getElementById("questionnaire1").style.display="none";
		document.getElementById("merchant1").style.display="none";
		}

		})
	
	})

	


/*固定框的脚本*/
/*下拉菜单栏显示*/
$(document).ready(
  function()
  {
	  $("#menuFather").mouseover(
	  function()
	  {
		 document.getElementById("menuShow").style.display="block";
		  })
	  })
$(document).ready(
  function()
  {
	  $("#menuFather").mouseout(
	  function()
	  {
		 document.getElementById("menuShow").style.display="none";
		  })
	  })
$(document).ready(
  function()
  {
	  $("#menuShow").mouseover(
	  function()
	  {
		 document.getElementById("menuShow").style.display="block";
		  })
	  })
	 $(document).ready(
  function()
  {
	  $("#menuShow").mouseout(
	  function()
	  {
		 document.getElementById("menuShow").style.display="none";
		  })
	  })
/*下拉菜单栏显示*/
/*菜单变换*/
$(document).ready(
function ()
{
	$(".mlbtR1").mouseover(
	function ()
	{
		document.getElementById("mlbl1").style.display="block";
		$(".mlbtR1").css("color","#FF0000");
		document.getElementById("mlbl2").style.display="none";
		$(".mlbtR2").css("color","#333333");
		document.getElementById("mlbl3").style.display="none";
		$(".mlbtR3").css("color","#333333");
		
		
		})
	})
$(document).ready(
function ()
{
	$(".mlbtR2").mouseover(
	function ()
	{
		document.getElementById("mlbl1").style.display="none";
		$(".mlbtR1").css("color","#333333");
		document.getElementById("mlbl2").style.display="block";
		$(".mlbtR2").css("color","#FF0000");
		document.getElementById("mlbl3").style.display="none";
		$(".mlbtR3").css("color","#333333");
		
		
		})
	})
$(document).ready(
function ()
{
	$(".mlbtR3").mouseover(
	function ()
	{
		document.getElementById("mlbl1").style.display="none";
		$(".mlbtR1").css("color","#333333");
		document.getElementById("mlbl2").style.display="none";
		$(".mlbtR2").css("color","#333333");
		document.getElementById("mlbl3").style.display="block";
		$(".mlbtR3").css("color","#FF0000");
		
		
		})
	})
/*菜单变换*/

/*$(document).ready(
function(){
$(".item1").click(
function()
{
    //$("this").style.display="block";
	$(".item1").slowDown("fast");
	})}
	)*/
$(function(){
	$("li").find("ul").prev().click(function(){
		$(this).next().toggle();
	});
	$("li:has(ul)").find("ul").hide();
});