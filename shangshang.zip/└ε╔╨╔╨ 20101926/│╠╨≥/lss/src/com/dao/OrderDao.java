﻿package com.dao;

import com.domain.OrderForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public OrderDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public List selectOrderHead(String name)
  {
    List list = new ArrayList();
    OrderForm order = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_order where name=?");
      this.ps.setString(1, name);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(order))
      {
        order = new OrderForm();
        order.setId(Integer.valueOf(rs.getString(1)));
        order.setNumber(rs.getString(2));
        order.setName(rs.getString(3));
        order.setReallyName(rs.getString(4));
        order.setAddress(rs.getString(5));
        order.setTel(rs.getString(6));
        order.setSetMoney(rs.getString(7));
        order.setPost(rs.getString(8));
        order.setBz(rs.getString(9));
        order.setSign(rs.getString(10));
        order.setCreaTime(rs.getString(11));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public OrderForm selectOrderNumber(String number)
  {
    OrderForm order = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_order where number=?");
      this.ps.setString(1, number);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); order.setCreaTime(rs.getString(11)))
      {
        order = new OrderForm();
        order.setId(Integer.valueOf(rs.getString(1)));
        order.setNumber(rs.getString(2));
        order.setName(rs.getString(3));
        order.setReallyName(rs.getString(4));
        order.setAddress(rs.getString(5));
        order.setTel(rs.getString(6));
        order.setSetMoney(rs.getString(7));
        order.setPost(rs.getString(8));
        order.setBz(rs.getString(9));
        order.setSign(rs.getString(10));
      }
    }
    catch (SQLException localSQLException) {
    }
    return order;
  }

  public void updateSignOrder(String number)
  {
    try
    {
      this.ps = this.connection.prepareStatement("update tb_order set sign=1 where number=?");
      this.ps.setString(1, number);
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public boolean deleteOrder(String number) {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_order where number=?");
      this.ps.setString(1, number);
      this.ps.executeUpdate();
      this.ps.close();
      return true;
    } catch (SQLException ex) {
    }
    return false;
  }

  public List selectOrderSign(Integer id)
  {
    List list = new ArrayList();
    OrderForm order = null;
    try
    {
      if (id == null)
      {
        this.ps = this.connection.prepareStatement("select * from tb_order order by id DESC");
      }
      else {
        this.ps = this.connection.prepareStatement("select * from tb_order where sign=? order by id DESC");
        this.ps.setInt(1, id.intValue());
      }
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(order))
      {
        order = new OrderForm();
        order.setId(Integer.valueOf(rs.getString(1)));
        order.setNumber(rs.getString(2));
        order.setName(rs.getString(3));
        order.setReallyName(rs.getString(4));
        order.setAddress(rs.getString(5));
        order.setTel(rs.getString(6));
        order.setSetMoney(rs.getString(7));
        order.setPost(rs.getString(8));
        order.setBz(rs.getString(9));
        order.setSign(rs.getString(10));
        order.setCreaTime(rs.getString(11));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public void insertOrderDetail(OrderForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("insert into tb_order values (?,?,?,?,?,?,?,?,?,getDate())");
      this.ps.setString(1, form.getNumber());
      this.ps.setString(2, form.getName());
      this.ps.setString(3, form.getReallyName());
      this.ps.setString(4, form.getAddress());
      this.ps.setString(5, form.getTel());
      this.ps.setString(6, form.getSetMoney());
      this.ps.setString(7, form.getPost());
      this.ps.setString(8, form.getBz());
      this.ps.setString(9, form.getSign());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }
}