﻿package com.dao;

import com.domain.MemberForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MemberDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public MemberDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public boolean updatePassword(String password, Integer id)
  {
    try {
      this.ps = this.connection.prepareStatement("update tb_member set password=? where id=?");
      this.ps.setString(1, password);
      this.ps.setInt(2, id.intValue());
      this.ps.executeUpdate();
      this.ps.close();
      return true;
    } catch (SQLException ex) {
    }
    return false;
  }

  public MemberForm selectFind(String name, String result)
  {
    MemberForm member = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_member where name=? and result=?");
      this.ps.setString(1, name);
      this.ps.setString(2, result);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); member.setResult(rs.getString(9)))
      {
        member = new MemberForm();
        member.setId(Integer.valueOf(rs.getString(1)));
        member.setName(rs.getString(2));
        member.setPassword(rs.getString(3));
        member.setReallyName(rs.getString(4));
        member.setAge(Integer.valueOf(rs.getString(5)));
        member.setProfession(rs.getString(6));
        member.setEmail(rs.getString(7));
        member.setQuestion(rs.getString(8));
      }
    }
    catch (SQLException localSQLException) {
    }
    return member;
  }

  public MemberForm selectMemberForm(String name)
  {
    MemberForm member = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_member where name=?");
      this.ps.setString(1, name);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); member.setResult(rs.getString(9)))
      {
        member = new MemberForm();
        member.setId(Integer.valueOf(rs.getString(1)));
        member.setName(rs.getString(2));
        member.setPassword(rs.getString(3));
        member.setReallyName(rs.getString(4));
        member.setAge(Integer.valueOf(rs.getString(5)));
        member.setProfession(rs.getString(6));
        member.setEmail(rs.getString(7));
        member.setQuestion(rs.getString(8));
      }
    }
    catch (SQLException localSQLException) {
    }
    return member;
  }

  public boolean deleteMember(Integer id)
  {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_member where id=?");
      this.ps.setString(1, id.toString());
      this.ps.executeUpdate();
      this.ps.close();
      return true;
    } catch (SQLException ex) {
    }
    return false;
  }

  public void insertMember(MemberForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("insert into tb_member values (?,?,?,?,?,?,?,?)");
      this.ps.setString(1, form.getName());
      this.ps.setString(2, form.getPassword());
      this.ps.setString(3, form.getReallyName());
      this.ps.setString(4, form.getAge().toString());
      this.ps.setString(5, form.getProfession());
      this.ps.setString(6, form.getEmail());
      this.ps.setString(7, form.getQuestion());
      this.ps.setString(8, form.getResult());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void updateMember(MemberForm form) {
    try {
      this.ps = this.connection.prepareStatement("update tb_member set name=?,password=?,reallyName=?,age=?,profession=?,email=?,question=?,result=? where id=?");
      this.ps.setString(1, form.getName());
      this.ps.setString(2, form.getPassword());
      this.ps.setString(3, form.getReallyName());
      this.ps.setString(4, form.getAge().toString());
      this.ps.setString(5, form.getProfession());
      this.ps.setString(6, form.getEmail());
      this.ps.setString(7, form.getQuestion());
      this.ps.setString(8, form.getResult());
      this.ps.setString(9, form.getId().toString());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public String selectPassword(String name) {
    String password = "";
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_member where name=?");
      this.ps.setString(1, name);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); )
        password = rs.getString("password");
    }
    catch (SQLException localSQLException) {
    }
    return password;
  }

  public List selectMember()
  {
    List list = new ArrayList();
    MemberForm member = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_member order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(member))
      {
        member = new MemberForm();
        member.setId(Integer.valueOf(rs.getString(1)));
        member.setName(rs.getString(2));
        member.setPassword(rs.getString(3));
        member.setReallyName(rs.getString(4));
        member.setAge(Integer.valueOf(rs.getString(5)));
        member.setProfession(rs.getString(6));
        member.setEmail(rs.getString(7));
        member.setQuestion(rs.getString(8));
        member.setResult(rs.getString(9));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public MemberForm selectOneMember(Integer id)
  {
    MemberForm member = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_member where id=?");
      this.ps.setInt(1, id.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); member.setResult(rs.getString(9)))
      {
        member = new MemberForm();
        member.setId(Integer.valueOf(rs.getString(1)));
        member.setName(rs.getString(2));
        member.setPassword(rs.getString(3));
        member.setReallyName(rs.getString(4));
        member.setAge(Integer.valueOf(rs.getString(5)));
        member.setProfession(rs.getString(6));
        member.setEmail(rs.getString(7));
        member.setQuestion(rs.getString(8));
      }
    }
    catch (SQLException localSQLException) {
    }
    return member;
  }
}