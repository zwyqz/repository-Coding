﻿package com.dao;

import com.domain.BigTypeForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BigTypeDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public BigTypeDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public String selectName(Integer id)
  {
    String name = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_bigType where id=?");
      this.ps.setString(1, id.toString());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); )
        name = rs.getString("bigName");
    }
    catch (SQLException localSQLException) {
    }
    return name;
  }

  public boolean deleteBig(Integer id)
  {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_bigType where id=?");
      this.ps.setString(1, id.toString());
      this.ps.executeUpdate();
      this.ps.close();
      return true;
    } catch (SQLException ex) {
    }
    return false;
  }

  public void updateBig(BigTypeForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("update tb_bigType set bigName=? where id=?");
      this.ps.setString(1, form.getBigName());
      this.ps.setString(2, form.getId().toString());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void insertBig(String name) {
    try {
      this.ps = this.connection.prepareStatement("insert into tb_bigType values (?,getDate())");
      this.ps.setString(1, name);
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public BigTypeForm selectOneBig(Integer id) {
    BigTypeForm big = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_bigType where id=?");
      this.ps.setString(1, id.toString());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); big.setCreaTime(rs.getString(3)))
      {
        big = new BigTypeForm();
        big.setId(Integer.valueOf(rs.getString(1)));
        big.setBigName(rs.getString(2));
      }
    }
    catch (SQLException localSQLException) {
    }
    return big;
  }

  public List selectBig()
  {
    List list = new ArrayList();
    BigTypeForm big = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_bigType order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(big))
      {
        big = new BigTypeForm();
        big.setId(Integer.valueOf(rs.getString(1)));
        big.setBigName(rs.getString(2));
        big.setCreaTime(rs.getString(3));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }
}