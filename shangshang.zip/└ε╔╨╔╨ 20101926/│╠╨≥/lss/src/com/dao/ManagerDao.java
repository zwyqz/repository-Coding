﻿package com.dao;

import com.domain.ManagerForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ManagerDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public ManagerDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public void insertManager(ManagerForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("insert into tb_manager values (?,?,?,?)");
      this.ps.setString(1, form.getAccount());
      this.ps.setString(2, form.getPassword());
      this.ps.setString(3, form.getName());
      this.ps.setInt(4, 0);
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void updateManagerPassword(ManagerForm form) {
    try {
      this.ps = this.connection.prepareStatement("update tb_manager set password=? where account=?");
      this.ps.setString(1, form.getPassword());
      this.ps.setString(2, form.getAccount());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void updateManager(ManagerForm form) {
    try {
      this.ps = this.connection.prepareStatement("update tb_manager set account=?,password=?,name=? where id=?");
      this.ps.setString(1, form.getAccount());
      this.ps.setString(2, form.getPassword());
      this.ps.setString(3, form.getName());
      this.ps.setInt(4, form.getId().intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void deleteManager(Integer id) {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_manager where id=?");
      this.ps.setInt(1, id.intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public List selectManager() {
    List list = new ArrayList();
    ManagerForm manager = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_manager order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(manager))
      {
        manager = new ManagerForm();
        manager.setId(Integer.valueOf(rs.getString(1)));
        manager.setAccount(rs.getString(2));
        manager.setPassword(rs.getString(3));
        manager.setName(rs.getString(4));
        manager.setSigh(Integer.valueOf(rs.getString(5)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public ManagerForm selectOne(String account)
  {
    ManagerForm manager = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_manager where account=?");
      this.ps.setString(1, account);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); manager.setSigh(Integer.valueOf(rs.getString(5))))
      {
        manager = new ManagerForm();
        manager.setId(Integer.valueOf(rs.getString(1)));
        manager.setAccount(rs.getString(2));
        manager.setPassword(rs.getString(3));
        manager.setName(rs.getString(4));
      }
    }
    catch (SQLException localSQLException) {
    }
    return manager;
  }

  public String selectPassword(String account)
  {
    String password = "";
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_manager where account=?");
      this.ps.setString(1, account);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); this.ps.close())
        password = rs.getString("password");
    }
    catch (SQLException localSQLException) {
    }
    return password;
  }
}