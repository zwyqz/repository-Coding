﻿package com.dao;

import com.domain.GoodsForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GoodsDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public GoodsDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public void updateGoodsNumber(int number, Integer id)
  {
    try
    {
      this.ps = this.connection.prepareStatement("update tb_goods set number=number+? where id=?");
      this.ps.setInt(1, number);
      this.ps.setInt(2, id.intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void managerPrice(GoodsForm form) {
    try {
      this.ps = this.connection.prepareStatement("update tb_goods set freePrice=?,mark=? where id=?");
      this.ps.setFloat(1, form.getFreePrice().floatValue());
      this.ps.setInt(2, form.getMark().intValue());
      this.ps.setInt(3, form.getId().intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public List selectMark(Integer mark) {
    List list = new ArrayList();
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods where mark=? order by id DESC");
      this.ps.setInt(1, mark.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(goods))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public void insertGoods(GoodsForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("insert into tb_goods values (?,?,?,?,?,getDate(),?,?,?,?,?)");
      this.ps.setInt(1, form.getBig().intValue());
      this.ps.setInt(2, form.getSmall().intValue());
      this.ps.setString(3, form.getName());
      this.ps.setString(4, form.getFrom());
      this.ps.setString(5, form.getIntroduce());
      this.ps.setFloat(6, form.getNowPrice().floatValue());
      this.ps.setFloat(7, form.getFreePrice().floatValue());
      this.ps.setInt(8, 0);
      this.ps.setString(9, form.getPicture());
      this.ps.setInt(10, 0);
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void deleteGoods(Integer id) {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_goods where id=?");
      this.ps.setInt(1, id.intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public GoodsForm selectOneGoods(Integer id) {
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods where id=? order by id DESC");
      this.ps.setInt(1, id.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); goods.setMark(Integer.valueOf(rs.getString(12))))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
      }
    }
    catch (SQLException localSQLException) {
    }
    return goods;
  }

  public List selectSmall(Integer small)
  {
    List list = new ArrayList();
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods where smallId=? order by id DESC");
      this.ps.setInt(1, small.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(goods))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public List selectBig(Integer big)
  {
    List list = new ArrayList();
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods where bigId=? order by id DESC");
      this.ps.setInt(1, big.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(goods))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public List selectGoods()
  {
    List list = new ArrayList();
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(goods))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public List selectGoodsNumber()
  {
    List list = new ArrayList();
    GoodsForm goods = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_goods order by number DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(goods))
      {
        goods = new GoodsForm();
        goods.setId(Integer.valueOf(rs.getString(1)));
        goods.setBig(Integer.valueOf(rs.getString(2)));
        goods.setSmall(Integer.valueOf(rs.getString(3)));
        goods.setName(rs.getString(4));
        goods.setFrom(rs.getString(5));
        goods.setIntroduce(rs.getString(6));
        goods.setCreaTime(rs.getString(7));
        goods.setNowPrice(Float.valueOf(rs.getString(8)));
        goods.setFreePrice(Float.valueOf(rs.getString(9)));
        goods.setNumber(Integer.valueOf(rs.getString(10)));
        goods.setPriture(rs.getString(11));
        goods.setMark(Integer.valueOf(rs.getString(12)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }
}