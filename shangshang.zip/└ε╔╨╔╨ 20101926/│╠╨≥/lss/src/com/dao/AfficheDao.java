﻿package com.dao;

import com.domain.AfficheForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AfficheDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public AfficheDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public void deleteAffiche(Integer id)
  {
    try
    {
      this.ps = this.connection.prepareStatement("delete from tb_affiche where id=?");
      this.ps.setInt(1, id.intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void updateAffiche(AfficheForm form) {
    try {
      this.ps = this.connection.prepareStatement("update tb_affiche set name=?,content=? where id=?");
      this.ps.setString(1, form.getName());
      this.ps.setString(2, form.getContent());
      this.ps.setInt(3, form.getId().intValue());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void insertAffiche(AfficheForm form) {
    try {
      this.ps = this.connection.prepareStatement("insert into tb_affiche values (?,?,getDate())");
      this.ps.setString(1, form.getName());
      this.ps.setString(2, form.getContent());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public AfficheForm selectOneAffiche(Integer id) {
    AfficheForm affiche = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_affiche where id=?");
      this.ps.setInt(1, id.intValue());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); affiche.setIssueTime(rs.getString(4)))
      {
        affiche = new AfficheForm();
        affiche.setId(Integer.valueOf(rs.getString(1)));
        affiche.setName(rs.getString(2));
        affiche.setContent(rs.getString(3));
      }
    }
    catch (SQLException localSQLException) {
    }
    return affiche;
  }

  public List selectAffiche()
  {
    List list = new ArrayList();
    AfficheForm affiche = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_affiche order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(affiche))
      {
        affiche = new AfficheForm();
        affiche.setId(Integer.valueOf(rs.getString(1)));
        affiche.setName(rs.getString(2));
        affiche.setContent(rs.getString(3));
        affiche.setIssueTime(rs.getString(4));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }
}