﻿package com.dao;

import com.domain.SmallTypeForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SmallTypeDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public SmallTypeDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public List selectOneBigId(Integer bigId)
  {
    List list = new ArrayList();
    SmallTypeForm small = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_smallType where bigId=?");
      this.ps.setString(1, bigId.toString());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(small))
      {
        small = new SmallTypeForm();
        small.setId(Integer.valueOf(rs.getString(1)));
        small.setBigId(Integer.valueOf(rs.getString(2)));
        small.setSmallName(rs.getString(3));
        small.setCreaTime(rs.getString(4));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public String selectName(Integer id)
  {
    String name = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_smallType where id=?");
      this.ps.setString(1, id.toString());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); )
        name = rs.getString("smallName");
    }
    catch (SQLException localSQLException) {
    }
    return name;
  }

  public boolean deleteSmall(Integer id)
  {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_smallType where id=?");
      this.ps.setString(1, id.toString());
      this.ps.executeUpdate();
      this.ps.close();
      return true;
    } catch (SQLException ex) {
    }
    return false;
  }

  public void updateSmall(SmallTypeForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("update tb_smallType set bigId=?,smallName=? where id=?");
      this.ps.setString(1, form.getBigId().toString());
      this.ps.setString(2, form.getSmallName());
      this.ps.setString(3, form.getId().toString());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void insertSmall(SmallTypeForm form) {
    try {
      this.ps = this.connection.prepareStatement("insert into tb_smallType values (?,?,getDate())");
      this.ps.setString(1, form.getBigId().toString());
      this.ps.setString(2, form.getSmallName());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException) {
    }
  }

  public SmallTypeForm selectOneBig(Integer id) {
    SmallTypeForm small = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_smallType where id=?");
      this.ps.setString(1, id.toString());
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); small.setCreaTime(rs.getString(4)))
      {
        small = new SmallTypeForm();
        small.setId(Integer.valueOf(rs.getString(1)));
        small.setBigId(Integer.valueOf(rs.getString(2)));
        small.setSmallName(rs.getString(3));
      }
    }
    catch (SQLException localSQLException) {
    }
    return small;
  }

  public List selectSmall()
  {
    List list = new ArrayList();
    SmallTypeForm small = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_smallType order by id DESC");
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(small))
      {
        small = new SmallTypeForm();
        small.setId(Integer.valueOf(rs.getString(1)));
        small.setBigId(Integer.valueOf(rs.getString(2)));
        small.setSmallName(rs.getString(3));
        small.setCreaTime(rs.getString(4));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }
}