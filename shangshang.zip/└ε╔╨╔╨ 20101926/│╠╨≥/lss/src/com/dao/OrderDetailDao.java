﻿package com.dao;

import com.domain.OrderDetailForm;
import com.tool.JDBConnection;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDetailDao
{
  private Connection connection;
  private PreparedStatement ps;
  private JDBConnection jdbc;

  public OrderDetailDao()
  {
    this.connection = null;
    this.ps = null;
    this.jdbc = null;
    this.jdbc = new JDBConnection();
    this.connection = this.jdbc.connection;
  }

  public List selectOrderDetailNumber(String number)
  {
    List list = new ArrayList();
    OrderDetailForm orderDetail = null;
    try
    {
      this.ps = this.connection.prepareStatement("select * from tb_orderDetail where orderNumber=?");
      this.ps.setString(1, number);
      for (ResultSet rs = this.ps.executeQuery(); rs.next(); list.add(orderDetail))
      {
        orderDetail = new OrderDetailForm();
        orderDetail.setId(Integer.valueOf(rs.getString(1)));
        orderDetail.setOrderNumber(rs.getString(2));
        orderDetail.setGoodsId(Integer.valueOf(rs.getString(3)));
        orderDetail.setPrice(Float.parseFloat(rs.getString(4)));
        orderDetail.setNumber(Integer.parseInt(rs.getString(5)));
      }
    }
    catch (SQLException localSQLException) {
    }
    return list;
  }

  public void insertOrderDetail(OrderDetailForm form)
  {
    try
    {
      this.ps = this.connection.prepareStatement("insert into tb_orderDetail values (?,?,?,?)");
      this.ps.setString(1, form.getOrderNumber());
      this.ps.setString(2, form.getGoodsId().toString());
      this.ps.setFloat(3, form.getPrice());
      this.ps.setInt(4, form.getNumber());
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }

  public void deleteOrderDetail(String number) {
    try {
      this.ps = this.connection.prepareStatement("delete from tb_orderDetail where orderNumber=?");
      System.out.println(number + "+3231+");
      this.ps.setString(1, number);
      this.ps.executeUpdate();
      this.ps.close();
    }
    catch (SQLException localSQLException)
    {
    }
  }
}