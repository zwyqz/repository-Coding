﻿package com.dao;

import com.domain.LinkForm;
import com.tool.JDBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LinkDao {
	private Connection connection;
	private PreparedStatement ps;
	private JDBConnection jdbc;

	public LinkDao() {
		this.connection = null;
		this.ps = null;
		this.jdbc = null;
		this.jdbc = new JDBConnection();
		this.connection = this.jdbc.connection;
	}

	public void deleteLink(Integer id) {
		try {
			this.ps = this.connection
					.prepareStatement("delete from tb_link where id=?");
			this.ps.setInt(1, id.intValue());
			this.ps.executeUpdate();
			this.ps.close();
		} catch (SQLException localSQLException) {
		}
	}

	public void insertLink(LinkForm form) {
		try {
			this.ps = this.connection
					.prepareStatement("insert into tb_link values (?,?,?,getDate())");
			this.ps.setString(1, form.getLinkName());
			this.ps.setString(2, form.getLinkAddress());
			this.ps.setString(3, form.getLinkPicture());
			this.ps.executeUpdate();
			this.ps.close();
		} catch (SQLException localSQLException) {
		}
	}

	public LinkForm selectOneLink(Integer id) {
		LinkForm link = null;
		try {
			this.ps = this.connection
					.prepareStatement("select * from tb_link where id=?");
			this.ps.setInt(1, id.intValue());
			for (ResultSet rs = this.ps.executeQuery(); rs.next(); link
					.setLinkTime(rs.getString(5))) {
				link = new LinkForm();
				link.setId(Integer.valueOf(rs.getString(1)));
				link.setLinkName(rs.getString(2));
				link.setLinkAddress(rs.getString(3));
				link.setLinkPicture(rs.getString(4));
			}
		} catch (SQLException localSQLException) {
		}
		return link;
	}

	public LinkForm selectOneAddress(String address) {
		LinkForm link = null;
		try {
			this.ps = this.connection
					.prepareStatement("select * from tb_link where linkAddress=?");
			this.ps.setString(1, address);
			for (ResultSet rs = this.ps.executeQuery(); rs.next(); link
					.setLinkTime(rs.getString(5))) {
				link = new LinkForm();
				link.setId(Integer.valueOf(rs.getString(1)));
				link.setLinkName(rs.getString(2));
				link.setLinkAddress(rs.getString(3));
				link.setLinkPicture(rs.getString(4));
			}
		} catch (SQLException localSQLException) {
		}
		return link;
	}

	public LinkForm selectOneName(String name) {
		LinkForm link = null;
		try {
			this.ps = this.connection
					.prepareStatement("select * from tb_link where linkName=?");
			this.ps.setString(1, name);
			for (ResultSet rs = this.ps.executeQuery(); rs.next(); link
					.setLinkTime(rs.getString(5))) {
				link = new LinkForm();
				link.setId(Integer.valueOf(rs.getString(1)));
				link.setLinkName(rs.getString(2));
				link.setLinkAddress(rs.getString(3));
				link.setLinkPicture(rs.getString(4));
			}
		} catch (SQLException localSQLException) {
		}
		return link;
	}

	public List selectLink() {
		List list = new ArrayList();
		LinkForm link = null;
		try {
			this.ps = this.connection
					.prepareStatement("select * from tb_link order by id DESC");
			for (ResultSet rs = this.ps.executeQuery(); rs.next(); list
					.add(link)) {
				link = new LinkForm();
				link.setId(Integer.valueOf(rs.getString(1)));
				link.setLinkName(rs.getString(2));
				link.setLinkAddress(rs.getString(3));
				link.setLinkPicture(rs.getString(4));
				link.setLinkTime(rs.getString(5));
			}
		} catch (SQLException localSQLException) {
		}
		return list;
	}
}