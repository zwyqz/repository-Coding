﻿package com.tool;

import java.io.PrintStream;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

public class ManagerTrace
  implements HttpSessionBindingListener
{
  private int id;
  private ManagerList container;
  private MemberList member;

  public ManagerTrace()
  {
    this.container = ManagerList.getInstance();
    this.member = MemberList.getInstance();
    this.id = 0;
  }

  public void setId(int id)
  {
    this.id = id;
  }

  public int getId()
  {
    return this.id;
  }

  public void valueBound(HttpSessionBindingEvent arg0)
  {
    System.out.println("上线" + this.id);
  }

  public void valueUnbound(HttpSessionBindingEvent arg0)
  {
    System.out.println("下线" + this.id);
    if (this.id == -1)
      return;
    this.container.removeManager(this.id);
    this.member.removeMember(this.id);
  }
}