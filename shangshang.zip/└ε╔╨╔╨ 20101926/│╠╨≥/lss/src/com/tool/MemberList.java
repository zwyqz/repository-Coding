﻿package com.tool;

import com.domain.MemberForm;
import java.util.Vector;

public class MemberList
{
  private static MemberList manager = new MemberList();
  private Vector vector;

  public MemberList()
  {
    this.vector = null;
    this.vector = new Vector();
  }

  public static MemberList getInstance()
  {
    return manager;
  }

  public boolean addMember(MemberForm form)
  {
    if (form != null)
    {
      this.vector.add(form);
      return true;
    }

    return false;
  }

  public Vector getList()
  {
    return this.vector;
  }

  public int removeMember(int id)
  {
    for (int i = 0; i < this.vector.size(); ++i)
    {
      MemberForm form = (MemberForm)this.vector.elementAt(i);
      int idd = form.getId().intValue();
      if (idd == id) {
        this.vector.removeElementAt(i);
      }
    }
    return id;
  }
}