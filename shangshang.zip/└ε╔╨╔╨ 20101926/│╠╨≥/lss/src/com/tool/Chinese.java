﻿package com.tool;

import java.io.UnsupportedEncodingException;

public class Chinese
{
  public static String toUnicode(String strvalue)
  {
    if (strvalue == null)
      return null;
    try {
      strvalue = new String(strvalue.getBytes("GBK"), "ISO8859_1");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return "";
  }

  public static String StringtoSql(String str)
  {
    str = nullToString(str, "");
    try {
      str = str.trim().replace('\'', '\1');
    } catch (Exception e) {
      return "";
    }
    return str;
  }

  public static final String nullToString(String v, String toV) {
    if (v == null)
      v = toV;
    return v;
  }

  public static String toChinese(String strvalue) {
    if (strvalue == null)
      return "";
    try
    {
      strvalue = new String(strvalue.getBytes("ISO8859_1"), "GBK");
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    return strvalue;
  }

  public static String chinese(String a)
  {
    try
    {
      return new String(a.getBytes("ISO-8859-1"));
    }
    catch (UnsupportedEncodingException e) {
      e.printStackTrace();
    }
    return null;
  }
}