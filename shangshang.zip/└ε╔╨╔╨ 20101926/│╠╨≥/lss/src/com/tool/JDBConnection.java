﻿package com.tool;

import java.sql.Connection;
import java.sql.DriverManager;

public class JDBConnection {
	private String dbDriver;
	private String url;
	public Connection connection;

	public JDBConnection() {
		this.dbDriver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
		this.url = "jdbc:sqlserver://localhost:1433; DatabaseName=db_shopping";
		this.connection = null;
		try {
			Class.forName(this.dbDriver).newInstance();
			this.connection = DriverManager.getConnection(this.url, "sa",
					"8888");
		} catch (Exception ex) {
			System.out.println("数据库加载失败");
		}
	}
}