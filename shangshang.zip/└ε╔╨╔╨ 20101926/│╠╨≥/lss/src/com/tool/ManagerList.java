﻿package com.tool;

import com.domain.ManagerForm;
import java.util.Vector;

public class ManagerList
{
  private static ManagerList manager = new ManagerList();
  private Vector vector;

  public ManagerList()
  {
    this.vector = null;
    this.vector = new Vector();
  }

  public static ManagerList getInstance()
  {
    return manager;
  }

  public boolean addManager(ManagerForm form)
  {
    if (form != null)
    {
      this.vector.add(form);
      return true;
    }

    return false;
  }

  public Vector getList()
  {
    return this.vector;
  }

  public int removeManager(int id)
  {
    for (int i = 0; i < this.vector.size(); ++i)
    {
      ManagerForm form = (ManagerForm)this.vector.elementAt(i);
      int idd = form.getId().intValue();
      if (idd == id) {
        this.vector.removeElementAt(i);
      }
    }
    return id;
  }
}