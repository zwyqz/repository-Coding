﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class SmallTypeForm extends ActionForm
{
  private Integer bigId;
  private String creaTime;
  private Integer id;
  private String smallName;

  public SmallTypeForm()
  {
    this.bigId = Integer.valueOf("-1");
    this.creaTime = "";
    this.id = Integer.valueOf("-1");
    this.smallName = "";
  }

  public Integer getBigId()
  {
    return this.bigId;
  }

  public void setBigId(Integer bigId)
  {
    this.bigId = bigId;
  }

  public void setSmallName(String smallName)
  {
    this.smallName = smallName;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public void setCreaTime(String creaTime)
  {
    this.creaTime = creaTime;
  }

  public String getCreaTime()
  {
    return this.creaTime;
  }

  public Integer getId()
  {
    return this.id;
  }

  public String getSmallName()
  {
    return this.smallName;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}