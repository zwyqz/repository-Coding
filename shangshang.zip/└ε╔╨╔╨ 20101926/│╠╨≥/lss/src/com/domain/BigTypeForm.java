﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class BigTypeForm extends ActionForm
{
  private String bigName;
  private String creaTime;
  private Integer id;

  public BigTypeForm()
  {
    this.bigName = "";
    this.creaTime = "";
    this.id = Integer.valueOf("-1");
  }

  public String getBigName()
  {
    return this.bigName;
  }

  public void setBigName(String bigName)
  {
    this.bigName = bigName;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public void setCreaTime(String creaTime)
  {
    this.creaTime = creaTime;
  }

  public String getCreaTime()
  {
    return this.creaTime;
  }

  public Integer getId()
  {
    return this.id;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}