﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class OrderDetailForm extends ActionForm
{
  private Integer goodsId;
  private Integer id;
  private String orderNumber;
  private float price;
  private int number;

  public Integer getGoodsId()
  {
    return this.goodsId;
  }

  public void setGoodsId(Integer goodsId)
  {
    this.goodsId = goodsId;
  }

  public void setOrderNumber(String orderNumber)
  {
    this.orderNumber = orderNumber;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public void setNumber(int number)
  {
    this.number = number;
  }

  public void setPrice(float price)
  {
    this.price = price;
  }

  public Integer getId()
  {
    return this.id;
  }

  public String getOrderNumber()
  {
    return this.orderNumber;
  }

  public int getNumber()
  {
    return this.number;
  }

  public float getPrice()
  {
    return this.price;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}