﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class ManagerForm extends ActionForm
{
  private String account;
  private Integer id;
  private String name;
  private String password;
  private Integer sigh;

  public ManagerForm()
  {
    this.account = "";
    this.id = Integer.valueOf("-1");
    this.name = "";
    this.password = "";
    this.sigh = Integer.valueOf("-1");
  }

  public String getAccount()
  {
    return this.account;
  }

  public void setAccount(String account)
  {
    this.account = account;
  }

  public void setSigh(Integer sigh)
  {
    this.sigh = sigh;
  }

  public void setPassword(String password)
  {
    this.password = password;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public Integer getId()
  {
    return this.id;
  }

  public String getName()
  {
    return this.name;
  }

  public String getPassword()
  {
    return this.password;
  }

  public Integer getSigh()
  {
    return this.sigh;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}