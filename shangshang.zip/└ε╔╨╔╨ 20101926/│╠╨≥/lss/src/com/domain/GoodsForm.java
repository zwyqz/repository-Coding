﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class GoodsForm extends ActionForm
{
  private Integer big;
  private String creaTime;
  private Float freePrice;
  private String from;
  private Integer id;
  private String introduce;
  private String name;
  private Float nowPrice;
  private Integer number;
  private Integer small;
  private String priture;
  private Integer mark;

  public Integer getBig()
  {
    return this.big;
  }

  public Integer getMark()
  {
    return this.mark;
  }

  public void setBig(Integer big)
  {
    this.big = big;
  }

  public void setMark(Integer mark)
  {
    this.mark = mark;
  }

  public void setSmall(Integer small)
  {
    this.small = small;
  }

  public void setPriture(String priture)
  {
    this.priture = priture;
  }

  public void setNumber(Integer number)
  {
    this.number = number;
  }

  public void setNowPrice(Float nowPrice)
  {
    this.nowPrice = nowPrice;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public void setIntroduce(String introduce)
  {
    this.introduce = introduce;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public void setFrom(String from)
  {
    this.from = from;
  }

  public void setFreePrice(Float freePrice)
  {
    this.freePrice = freePrice;
  }

  public void setCreaTime(String creaTime)
  {
    this.creaTime = creaTime;
  }

  public String getCreaTime()
  {
    return this.creaTime;
  }

  public Float getFreePrice()
  {
    return this.freePrice;
  }

  public String getPicture()
  {
    return this.priture;
  }

  public String getFrom()
  {
    return this.from;
  }

  public Integer getId()
  {
    return this.id;
  }

  public String getIntroduce()
  {
    return this.introduce;
  }

  public String getName()
  {
    return this.name;
  }

  public Float getNowPrice()
  {
    return this.nowPrice;
  }

  public Integer getNumber()
  {
    return this.number;
  }

  public Integer getSmall()
  {
    return this.small;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}