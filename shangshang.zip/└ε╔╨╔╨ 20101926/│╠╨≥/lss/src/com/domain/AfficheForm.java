﻿package com.domain;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class AfficheForm extends ActionForm
{
  private String content;
  private Integer id;
  private String issueTime;
  private String name;

  public AfficheForm()
  {
    this.content = "";
    this.id = new Integer(-1);
    this.issueTime = "";
    this.name = "";
  }

  public String getContent()
  {
    return this.content;
  }

  public void setContent(String content)
  {
    this.content = content;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  public void setIssueTime(String issueTime)
  {
    this.issueTime = issueTime;
  }

  public void setId(Integer id)
  {
    this.id = id;
  }

  public Integer getId()
  {
    return this.id;
  }

  public String getIssueTime()
  {
    return this.issueTime;
  }

  public String getName()
  {
    return this.name;
  }

  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest)
  {
    return null;
  }

  public void reset(ActionMapping actionmapping, HttpServletRequest httpservletrequest)
  {
  }
}