﻿package com.domain;

public class SellGoodsForm
{
  public int ID;
  public float price;
  public int number;
}