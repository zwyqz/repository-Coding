﻿package com.webtier;

import com.dao.OrderDao;
import com.dao.OrderDetailDao;
import com.domain.OrderForm;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class OrderAction extends Action
{
  private int action;
  private OrderDao order;
  private OrderDetailDao orderDetail;

  public OrderAction()
  {
    this.order = null;
    this.orderDetail = null;
  }

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    this.action = Integer.parseInt(request.getParameter("action"));
    this.order = new OrderDao();
    this.orderDetail = new OrderDetailDao();
    switch (this.action)
    {
    case 0:
      return selectOrder(mapping, form, request, response);
    case 1:
      return selectOrderSend(mapping, form, request, response);
    case 2:
      return deleteOrder(mapping, form, request, response);
    case 3:
      return selectOneOrder(mapping, form, request, response);
    }
    OrderForm orderForm = (OrderForm)form;
    throw new UnsupportedOperationException("Method $execute() not yet implemented.");
  }

  public ActionForward selectOneOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String number = request.getParameter("number");
    request.setAttribute("orderForm", this.order.selectOrderNumber(number));
    request.setAttribute("orderDetailList", this.orderDetail.selectOrderDetailNumber(number));
    return mapping.findForward("selectOneOrder");
  }

  public ActionForward deleteOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String number = request.getParameter("number");
    this.orderDetail.deleteOrderDetail(number);
    if (this.order.deleteOrder(number))
      request.setAttribute("success", "删除信息成功！！！");
    else
      request.setAttribute("success", "删除信息失败！！！");
    return mapping.findForward("operationOrder");
  }

  public ActionForward selectOrderSend(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    this.order.updateSignOrder(request.getParameter("number"));
    request.setAttribute("success", "出货成功！！！");
    return mapping.findForward("operationOrder");
  }

  public ActionForward selectOrder(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    Integer sign = null;
    if (request.getParameter("sign") != null)
      sign = Integer.valueOf(request.getParameter("sign"));
    List list = this.order.selectOrderSign(sign);
    int pageNumber = list.size();
    int maxPage = pageNumber;
    String number = request.getParameter("i");
    if (maxPage % 6 == 0)
      maxPage /= 6;
    else
      maxPage = maxPage / 6 + 1;
    if (number == null)
      number = "0";
    request.setAttribute("number", String.valueOf(number));
    request.setAttribute("maxPage", String.valueOf(maxPage));
    request.setAttribute("pageNumber", String.valueOf(pageNumber));
    request.setAttribute("list", list);
    return mapping.findForward("selectOrder");
  }
}