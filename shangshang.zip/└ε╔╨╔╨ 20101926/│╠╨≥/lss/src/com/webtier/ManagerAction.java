﻿package com.webtier;

import com.dao.ManagerDao;
import com.domain.ManagerForm;
import com.tool.Chinese;
import com.tool.ManagerList;
import com.tool.ManagerTrace;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class ManagerAction extends Action
{
  private ManagerDao dao;
  private int action;
  private HttpSession session;

  public ManagerAction()
  {
    this.dao = null;
    this.session = null;
  }

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    this.dao = new ManagerDao();
    this.action = Integer.parseInt(request.getParameter("action"));
    switch (this.action)
    {
    case 0:
      return managerCheck(mapping, form, request, response);
    case 1:
      return managerSelect(mapping, form, request, response);
    case 2:
      return managerForwardInsert(mapping, form, request, response);
    case 3:
      return managerInsert(mapping, form, request, response);
    case 4:
      return managerDelete(mapping, form, request, response);
    case 5:
      return managerSelectContent(mapping, form, request, response);
    case 6:
      return managerUpdate(mapping, form, request, response);
    case 7:
      return managerForwardPassword(mapping, form, request, response);
    case 8:
      return managerUpdatePassword(mapping, form, request, response);
    }
    throw new UnsupportedOperationException("Method $execute() not yet implemented.");
  }

  public ActionForward managerUpdatePassword(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    ManagerForm managerForm = (ManagerForm)form;
    managerForm.setAccount(request.getParameter("account"));
    managerForm.setPassword(request.getParameter("password"));
    this.dao.updateManagerPassword(managerForm);
    request.setAttribute("success", "修改后台管理员密码成功！！！");
    return mapping.findForward("managerOperation");
  }

  public ActionForward managerForwardPassword(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    return mapping.findForward("managerForwardPassword");
  }

  public ActionForward managerUpdate(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    ManagerForm managerForm = (ManagerForm)form;
    managerForm.setAccount(request.getParameter("account"));
    managerForm.setPassword(request.getParameter("password"));
    managerForm.setName(Chinese.chinese(request.getParameter("name")));
    managerForm.setId(Integer.valueOf(request.getParameter("id")));
    this.dao.updateManager(managerForm);
    request.setAttribute("success", "修改后台管理员信息成功！！！");
    return mapping.findForward("managerOperation");
  }

  public ActionForward managerSelectContent(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    request.setAttribute("manager", this.dao.selectOne(request.getParameter("account")));
    return mapping.findForward("managerSelectContent");
  }

  public ActionForward managerDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    this.dao.deleteManager(Integer.valueOf(request.getParameter("id")));
    request.setAttribute("success", "删除后台管理员信息成功！！！");
    return mapping.findForward("managerOperation");
  }

  public ActionForward managerInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    ManagerForm managerForm = (ManagerForm)form;
    String account = request.getParameter("account");
    ManagerForm manager = this.dao.selectOne(account);
    if ((manager == null) || (manager.equals("")))
    {
      managerForm.setAccount(account);
      managerForm.setPassword(request.getParameter("password"));
      managerForm.setName(Chinese.chinese(request.getParameter("name")));
      this.dao.insertManager(managerForm);
      request.setAttribute("success", "添加后台管理员信息成功！！！");
    }
    else {
      request.setAttribute("success", "此用户名已经存在！！！");
    }
    return mapping.findForward("managerOperation");
  }

  public ActionForward managerForwardInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    return mapping.findForward("managerForwardInsert");
  }

  public ActionForward managerSelect(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    List list = this.dao.selectManager();
    int pageNumber = list.size();
    int maxPage = pageNumber;
    String number = request.getParameter("i");
    if (maxPage % 7 == 0)
      maxPage /= 7;
    else
      maxPage = maxPage / 7 + 1;
    if (number == null)
      number = "0";
    request.setAttribute("number", String.valueOf(number));
    request.setAttribute("maxPage", String.valueOf(maxPage));
    request.setAttribute("pageNumber", String.valueOf(pageNumber));
    request.setAttribute("list", list);
    return mapping.findForward("managerSelect");
  }

  public ActionForward managerCheck(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String account = Chinese.chinese(request.getParameter("account"));
    String password = this.dao.selectPassword(account);
    boolean flag = true;
    this.session = request.getSession();
    ManagerList manger = ManagerList.getInstance();
    Vector vc = manger.getList();
    ManagerForm manager = this.dao.selectOne(account);
    if ((!(vc.isEmpty())) && (vc != null))
    {
      Enumeration en = vc.elements();
      while (true)
      {
        if (!(en.hasMoreElements()))
          break;
        ManagerForm admin = (ManagerForm)en.nextElement();
        if (admin.getAccount().equals(account));
        flag = false;
      }
    }

    flag = true;

    if ((password.equals("")) || (password == null))
    {
      label127: request.setAttribute("result", "您输入的账号和密码不存在！！！");
      return mapping.findForward("checkResult");
    }
    if (!(password.equals(Chinese.chinese(request.getParameter("password")))))
    {
      request.setAttribute("result", "您输入的密码不存在！！！");
      return mapping.findForward("checkResult");
    }
    if (!(flag))
    {
      request.setAttribute("result", "您输入的用户名正在使用中！！！");
      return mapping.findForward("checkResult");
    }

    int id = manager.getId().intValue();
    ManagerTrace managerTrace = new ManagerTrace();
    managerTrace.setId(id);
    manger.addManager(manager);
    this.session.setAttribute("managerTrace", managerTrace);
    this.session.setAttribute("id", String.valueOf(id));
    request.setAttribute("manager", manager);
    return mapping.findForward("checkResult");
  }
}