﻿package com.webtier;

import com.dao.MemberDao;
import com.domain.MemberForm;
import com.tool.Chinese;
import com.tool.ManagerTrace;
import com.tool.MemberList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class MemberAction extends Action
{
  private int action;
  private MemberDao dao;
  private HttpSession session;

  public MemberAction()
  {
    this.dao = null;
    this.session = null;
  }

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    this.dao = new MemberDao();
    this.action = Integer.parseInt(request.getParameter("action"));
    switch (this.action)
    {
    case 0:
      return insertMember(mapping, form, request, response);
    case 1:
      return checkMember(mapping, form, request, response);
    case 2:
      return selectMember(mapping, form, request, response);
    case 3:
      return selectOneMember(mapping, form, request, response);
    case 4:
      return deleteMember(mapping, form, request, response);
    case 5:
      return selectOneMemberHead(mapping, form, request, response);
    case 6:
      return updateMemberHead(mapping, form, request, response);
    }
    throw new UnsupportedOperationException("Method $execute() not yet implemented.");
  }

  public ActionForward updateMemberHead(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    MemberForm memberForm = (MemberForm)form;
    String name = Chinese.chinese(request.getParameter("name")).trim();
    memberForm.setId(Integer.valueOf(request.getParameter("id")));
    memberForm.setName(name);
    memberForm.setPassword(Chinese.chinese(request.getParameter("password")).trim());
    memberForm.setAge(Integer.valueOf(request.getParameter("age").trim()));
    memberForm.setEmail(request.getParameter("email"));
    memberForm.setReallyName(Chinese.chinese(request.getParameter("reallyName")).trim());
    memberForm.setProfession(Chinese.chinese(request.getParameter("profession")).trim());
    memberForm.setQuestion(Chinese.chinese(request.getParameter("question")).trim());
    memberForm.setResult(Chinese.chinese(request.getParameter("result")).trim());
    this.dao.updateMember(memberForm);
    request.setAttribute("success", "修改成功");
    return mapping.findForward("operationMember");
  }

  public ActionForward selectOneMemberHead(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    request.setAttribute("form", this.dao.selectOneMember(Integer.valueOf(request.getParameter("id"))));
    return mapping.findForward("selectOneMemberHead");
  }

  public ActionForward deleteMember(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    if (this.dao.deleteMember(Integer.valueOf(request.getParameter("id"))))
      request.setAttribute("success", "删除会员信息成功！！！");
    else
      request.setAttribute("success", "删除失败，请先删除子表中的内容！！！");
    return mapping.findForward("deleteMember");
  }

  public ActionForward selectOneMember(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    request.setAttribute("form", this.dao.selectOneMember(Integer.valueOf(request.getParameter("id"))));
    return mapping.findForward("selectOneMember");
  }

  public ActionForward selectMember(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    List list = this.dao.selectMember();
    int pageNumber = list.size();
    int maxPage = pageNumber;
    String number = request.getParameter("i");
    if (maxPage % 6 == 0)
      maxPage /= 6;
    else
      maxPage = maxPage / 6 + 1;
    if (number == null)
      number = "0";
    request.setAttribute("number", String.valueOf(number));
    request.setAttribute("maxPage", String.valueOf(maxPage));
    request.setAttribute("pageNumber", String.valueOf(pageNumber));
    request.setAttribute("list", list);
    return mapping.findForward("selectMember");
  }

  public ActionForward checkMember(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String name = Chinese.chinese(request.getParameter("name"));//获取表单里的的姓名
    String password = this.dao.selectPassword(name.trim());//根据姓名获取正确的密码
    boolean flag = true;
    this.session = request.getSession();
    MemberList member = MemberList.getInstance();
    Vector vc = member.getList();
    MemberForm memberForm = this.dao.selectMemberForm(name);
    if ((!(vc.isEmpty())) && (vc != null))
    {
      Enumeration en = vc.elements();
      while (true)
      {
        if (!(en.hasMoreElements()))
          break;
        MemberForm admin = (MemberForm)en.nextElement();
        if (admin.getName().equals(name));
        flag = false;
      }
    }

    flag = true;

    if (password.equals("")) {
      label130: request.setAttribute("result", "不存在此会员，请重新登录！！！");
    }
    else if (!(password.equals(Chinese.chinese(request.getParameter("password").trim())))) {
      request.setAttribute("result", "密码错误，请重新登录！！！");
    }
    else if (!(flag))
    {
      request.setAttribute("result", "该会员已经登录！！！");
    }
    else {
      int id = memberForm.getId().intValue();
      ManagerTrace managerTrace = new ManagerTrace();
      managerTrace.setId(id);
      member.addMember(memberForm);
      this.session.setAttribute("managerTrace", managerTrace);
      this.session.setAttribute("id", String.valueOf(id));
      request.setAttribute("id", String.valueOf(id));
      request.setAttribute("memberForm", memberForm);
    }
    return mapping.findForward("checkMember");
  }

  public ActionForward insertMember(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    MemberForm memberForm = (MemberForm)form;
    String name = Chinese.chinese(request.getParameter("name")).trim();
    if ((this.dao.selectPassword(name) == null) || (this.dao.selectPassword(name).equals("")))
    {
      memberForm.setName(name);
      memberForm.setPassword(Chinese.chinese(request.getParameter("password")).trim());
      memberForm.setAge(Integer.valueOf(request.getParameter("age").trim()));
      memberForm.setEmail(request.getParameter("email"));
      memberForm.setReallyName(Chinese.chinese(request.getParameter("reallyName")).trim());
      memberForm.setProfession(Chinese.chinese(request.getParameter("profession")).trim());
      memberForm.setQuestion(Chinese.chinese(request.getParameter("question")).trim());
      memberForm.setResult(Chinese.chinese(request.getParameter("result")).trim());
      this.dao.insertMember(memberForm);
      request.setAttribute("success", "注册成功");
    }
    else {
      request.setAttribute("success", "该会员名称已经存在！！！");
    }
    return mapping.findForward("operationMember");
  }
}