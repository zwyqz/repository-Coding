﻿package com.webtier;

import com.dao.LinkDao;
import com.domain.LinkForm;
import com.tool.Chinese;
import java.io.UnsupportedEncodingException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class LinkAction extends Action
{
  private LinkDao dao;
  private int action;

  public LinkAction()
  {
    this.dao = null;
  }

  public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
    throws UnsupportedEncodingException
  {
    request.setCharacterEncoding("gb2312");
    this.action = Integer.parseInt(request.getParameter("action"));
    this.dao = new LinkDao();
    switch (this.action)
    {
    case 0:
      return linkSelect(mapping, form, request, response);
    case 1:
      return linkForward(mapping, form, request, response);
    case 2:
      return linkInsertForwardOne(mapping, form, request, response);
    case 3:
      return linkInsert(mapping, form, request, response);
    case 4:
      return linkDelete(mapping, form, request, response);
    }
    throw new UnsupportedOperationException("Method $execute() not yet implemented.");
  }

  public ActionForward linkDelete(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String path = request.getParameter("path");
    this.dao.deleteLink(Integer.valueOf(request.getParameter("id")));
    request.setAttribute("success", "删除连接网站信息成功");
    return mapping.findForward("linkOperation");
  }

  public ActionForward linkInsert(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    LinkForm linkForm = (LinkForm)form;
    linkForm.setLinkAddress(Chinese.chinese(request.getParameter("address")));
    linkForm.setLinkName(Chinese.chinese(request.getParameter("name")));
    linkForm.setLinkPicture(Chinese.chinese(request.getParameter("path")));
    this.dao.insertLink(linkForm);
    request.setAttribute("success", "添加连接网站信息成功");
    return mapping.findForward("linkOperation");
  }

  public ActionForward linkInsertForwardOne(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    String name = Chinese.chinese(request.getParameter("name"));
    String address = Chinese.chinese(request.getParameter("address"));
    LinkForm linkName = this.dao.selectOneName(name);
    LinkForm linkAddress = this.dao.selectOneAddress(address);
    if (linkName != null) {
      request.setAttribute("result", "此网站的名称已经存在");
    }
    else if (linkAddress != null)
      request.setAttribute("result", "此网站的地址已经存在");
    return mapping.findForward("linkInsertForwardOne");
  }

  public ActionForward linkSelect(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    List list = this.dao.selectLink();
    int pageNumber = list.size();
    int maxPage = pageNumber;
    String number = request.getParameter("i");
    if (maxPage % 7 == 0)
      maxPage /= 7;
    else
      maxPage = maxPage / 7 + 1;
    if (number == null)
      number = "0";
    request.setAttribute("number", String.valueOf(number));
    request.setAttribute("maxPage", String.valueOf(maxPage));
    request.setAttribute("pageNumber", String.valueOf(pageNumber));
    request.setAttribute("list", list);
    return mapping.findForward("linkSelect");
  }

  public ActionForward linkForward(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
  {
    return mapping.findForward("linkForward");
  }
}