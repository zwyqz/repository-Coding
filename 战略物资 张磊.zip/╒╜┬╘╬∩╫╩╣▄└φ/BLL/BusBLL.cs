﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DBUtility;
using System.Data.SqlClient;
using Model;

namespace BLL
{
    public class BusBLL
    {

        #region Purchase
        public int Bus_Purchase_Insert(Bus_Purchase purchase)
        {
            string strsql = @" insert into Bus_Purchase values ('{0}','{1}','{2}','{3}','{4}')";
            strsql = string.Format(strsql, purchase.SheetID, purchase.VenderCode, purchase.Editor, purchase.EditDate, purchase.Note);
            List<string> list = new List<string>();
            list.Add(strsql);
            return DbHelperSQL.ExecuteSqlTran(list);

        }
        public int Bus_PurchaseItem_Insert(List<Bus_PurchaseItem> PurchaseItemlist)
        {
            List<string> list = new List<string>();
            foreach (Bus_PurchaseItem PurchaseItem in PurchaseItemlist)
            {
                string strsql = @" insert into Bus_PurchaseItem values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')";
                strsql = string.Format(strsql, PurchaseItem.SheetID, PurchaseItem.OrderNo, PurchaseItem.VaccineCode, PurchaseItem.ProductDate
                    , PurchaseItem.BatchID,PurchaseItem.Cost, PurchaseItem.Qty);
                list.Add(strsql);
                strsql = @"if exists (select * from dbo.bus_Stock where VaccineCode='" + PurchaseItem.VaccineCode + @"')
begin
	update bus_Stock set Qty=Qty+'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"'
	if exists (select * from dbo.bus_StockBatch where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"')
	begin
		update bus_StockBatch set Qty=Qty+'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"'
	end 
	else
	begin 
		insert into bus_StockBatch values ('" + PurchaseItem.VaccineCode + @"','" + PurchaseItem.BatchID + @"','" + PurchaseItem.ProductDate + @"','" + PurchaseItem.Qty + @"')
	end
end 
else
begin
	insert into bus_Stock values('" + PurchaseItem.VaccineCode + @"','" + PurchaseItem.Qty + @"')
	if exists (select * from dbo.bus_StockBatch where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"')
	begin
		update bus_StockBatch set Qty=Qty+'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"'
	end 
	else
	begin 
		insert into bus_StockBatch values ('" + PurchaseItem.VaccineCode + @"','" + PurchaseItem.BatchID + @"','" + PurchaseItem.ProductDate + @"','" + PurchaseItem.Qty + @"')
	end
end ";
                list.Add(strsql);
            }
            return DbHelperSQL.ExecuteSqlTran(list);
        }
        public int Bus_Purchase_Del(Bus_Purchase purchase)
        {
            List<string> list = new List<string>();

            DataTable dt = new DataTable();
            dt = Bus_PurchaseItem(purchase.SheetID).Tables[0];

            foreach (DataRow item in dt.Rows)
            {
                string VaccineCode = item["VaccineCode"].ToString();
                string Qty = item["Qty"].ToString();
                string BatchID = item["BatchID"].ToString();
                string e = @"update bus_Stock set Qty=Qty - '" + Qty + @"' where VaccineCode='" + VaccineCode + @"'
	update bus_StockBatch set Qty=Qty - '" + Qty + "' where VaccineCode='" + VaccineCode + "' and BatchID ='" + BatchID + "' ";
                list.Add(e);
            }

            string strsql1 = @"delete from Bus_PurchaseItem where SheetID='" + purchase.SheetID + "'";
            string strsql = @"delete from Bus_Purchase where SheetID='" + purchase.SheetID + "'";
            list.Add(strsql);
            list.Add(strsql1);

            return DbHelperSQL.ExecuteSqlTran(list);
        }
        public DataSet View_Purchase(string sheetid, string editdate, string VenderCode)
        {
            string strsql = @"select * from View_PurchaseMain where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid like '%" + sheetid + "%'";
            }
            if (editdate != "")
            {
                strsql += " and EditDate ='" + editdate + "'";
            }
            if (VenderCode != "")
            {
                strsql += " and VenderCode ='" + VenderCode + "'";
            }

            return DbHelperSQL.Query(strsql);
        }
        public DataSet View_Purchase(string sheetid)
        {
            string strsql = @"select * from View_Purchase where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid = '" + sheetid + "'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet Bus_PurchaseItem(string sheetid)
        {
            string strsql = @"select OrderNo,VaccineCode,BatchID,convert(varchar(10),ProductDate,120) as ProductDate,Qty from Bus_PurchaseItem where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid = '" + sheetid + "'";
            }
            return DbHelperSQL.Query(strsql);
        }


        #endregion

        #region Stock
        public DataSet BatchStock(string VaccineCode)
        {
            string strsql = @"select * from bus_StockBatch where VaccineCode ='" + VaccineCode + "' ";

            return DbHelperSQL.Query(strsql);
        }
        public bool CheckBatchID(string VaccineCode, string BatchID, string ProductDate)
        {
            string strsql = @"select count(*) from bus_StockBatch 
                where VaccineCode ='" + VaccineCode + "' and BatchID='" + BatchID + "' and convert(varchar(10),ProductDate,120)<>'" + ProductDate + "'";
            return DbHelperSQL.Exists(strsql);

        }
        public DataSet BatchStock(string VaccineCode, string Name)
        {
            string strsql = @"select * from View_Stock where 1=1 ";
            string strsql1 = @"select * from View_StockBatch where 1=1 ";
            if (VaccineCode != "")
            {
                strsql += "and VaccineCode like '%" + VaccineCode + "%'";
                strsql1 += "and VaccineCode like '%" + VaccineCode + "%'";
            }
            if (Name != "")
            {
                strsql += "and Name like '%" + Name + "%'";
                strsql1 += "and Name like '%" + Name + "%'";
            }
            return DbHelperSQL.Query(strsql + strsql1);
        }

        public DataSet Stock()
        {
            string strsql = @"select * from View_GoodsStock ";

            return DbHelperSQL.Query(strsql);
        }

        public DataSet CaiGouStock()
        {
            string strsql = @"select * from View_GoodsStock where Qty<StockLimit ";

            return DbHelperSQL.Query(strsql);
        }

        public DataSet YUJING()
        {
            string STRSQL = @"SELECT  a.VaccineCode 编码
,b.GoodsName 名称
,BatchID 批次号
,CONVERT(varchar(10),ProductDate,120)  生产日期
,CONVERT(varchar(10),dateadd(m,b.EffectiveMonth,ProductDate),120)  有效期至
,[Qty] 数量
FROM [bus_StockBatch] a 
inner join dbo.bas_Goods b on a.VaccineCode=b.GoodsCode
where dateadd(m,b.EffectiveMonth,ProductDate)<dateadd(m,-1,GETDATE())";
            return DbHelperSQL.Query(STRSQL);
        }
        public DataSet YUJING2()
        {
            string STRSQL = @"select 
GoodsCode 物资编码
,GoodsName 物资名称
,StockLimit 安全库存
,Qty 当前库存

from dbo.bus_Stock a
inner join dbo.bas_Goods b on a.VaccineCode=b.GoodsCode 
where a.qty<StockLimit";
            return DbHelperSQL.Query(STRSQL);
        }

        #endregion

        #region Sale
        public int Bus_Sale_Insert(Bus_Sale purchase)
        {
            string strsql = @" insert into Bus_Sale values ('{0}','{1}','{2}','{3}','{4}')";
            strsql = string.Format(strsql, purchase.SheetID, purchase.CustomerCode, purchase.Editor, purchase.EditDate, purchase.Note);
            List<string> list = new List<string>();
            list.Add(strsql);
            return DbHelperSQL.ExecuteSqlTran(list);

        }
        public int Bus_SaleItem_Insert(List<Bus_SaleItem> PurchaseItemlist)
        {
            List<string> list = new List<string>();
            foreach (Bus_SaleItem PurchaseItem in PurchaseItemlist)
            {
                string strsql = @" insert into Bus_SaleItem values ('{0}','{1}','{2}','{3}','{4}','{5}')";
                strsql = string.Format(strsql, PurchaseItem.SheetID, PurchaseItem.OrderNo, PurchaseItem.VaccineCode, PurchaseItem.BatchID,PurchaseItem.Price, PurchaseItem.Qty);
                list.Add(strsql);
                strsql = @"if exists (select * from dbo.bus_Stock where VaccineCode='" + PurchaseItem.VaccineCode + @"')
begin
	update bus_Stock set Qty=Qty-'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"'
	update bus_StockBatch set Qty=Qty-'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"'
end 
else
begin
	insert into bus_Stock values('" + PurchaseItem.VaccineCode + @"',(-1)*" + PurchaseItem.Qty + @")
	update bus_StockBatch set Qty=Qty-'" + PurchaseItem.Qty + @"' where VaccineCode='" + PurchaseItem.VaccineCode + @"' and BatchID='" + PurchaseItem.BatchID + @"'
	
end ";
                list.Add(strsql);
            }
            return DbHelperSQL.ExecuteSqlTran(list);
        }
        public int Bus_Sale_Del(Bus_Sale purchase)
        {
            List<string> list = new List<string>();

            DataTable dt = new DataTable();
            dt = Bus_SaleItem(purchase.SheetID).Tables[0];

            foreach (DataRow item in dt.Rows)
            {
                string VaccineCode = item["VaccineCode"].ToString();
                string Qty = item["Qty"].ToString();
                string BatchID = item["BatchID"].ToString();
                string e = @"update bus_Stock set Qty=Qty + '" + Qty + @"' where VaccineCode='" + VaccineCode + @"'
	update bus_StockBatch set Qty=Qty + '" + Qty + "' where VaccineCode='" + VaccineCode + "' and BatchID ='" + BatchID + "' ";
                list.Add(e);
            }

            string strsql1 = @"delete from Bus_SaleItem where SheetID='" + purchase.SheetID + "'";
            string strsql = @"delete from Bus_Sale where SheetID='" + purchase.SheetID + "'";
            list.Add(strsql);
            list.Add(strsql1);

            return DbHelperSQL.ExecuteSqlTran(list);
        }
        public DataSet View_Sale(string sheetid, string editdate,string customerid)
        {
            string strsql = @"select * from View_SaleMain where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid like '%" + sheetid + "%'";
            }
            if (editdate != "")
            {
                strsql += " and EditDate ='" + editdate + "'";
            }
            if (customerid != "")
            {
                strsql += " and CustomerCode ='" + customerid + "'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet View_Sale(string sheetid)
        {
            string strsql = @"select * from View_Sale where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid = '" + sheetid + "'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet Bus_SaleItem(string sheetid)
        {
            string strsql = @"select OrderNo,VaccineCode,BatchID,Qty from Bus_SaleItem where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid = '" + sheetid + "'";
            }
            return DbHelperSQL.Query(strsql);
        }

        #endregion

        #region PD
        public DataSet PD(string sheetid, string pddate)
        {
            string strsql = @" select * from Bus_PD where 1=1 ";
            if (sheetid != "")
            {
                strsql += " and sheetid like '%" + sheetid + "%'";
            }
            if (pddate != "")
            {
                strsql += " and convert(varchar(10),pddate,120)='" + pddate + "'";
            }

            return DbHelperSQL.Query(strsql);
        }
        public DataSet PDItem(string sheetid)
        {
            string strsql = @" select * from View_PDItem where sheetid='" + sheetid + "'";
            return DbHelperSQL.Query(strsql);
        }

        public int InsertPD(string sheetid, string PDDate, string Editor)
        {
            string strsql = @"insert into Bus_PD values ('{0}','{1}','{2}')";
            strsql = string.Format(strsql, sheetid, PDDate, Editor);
            return DbHelperSQL.ExecuteSql(strsql);
        }
        public int InsertPDItem(string sheetid, string OrderNO, string GoodsID, string ZS, string SP, string CY)
        {
            string strsql = @"insert into Bus_PDItem values('{0}',{1},'{2}','{3}','{4}','{5}')";
            strsql = string.Format(strsql, sheetid, OrderNO, GoodsID, ZS, SP, CY);

            return DbHelperSQL.ExecuteSql(strsql);
        }
        public int DeletePD(string sheetid)
        {

            string strql = "delete from Bus_PDItem where sheetid = '" + sheetid + "'";
            DbHelperSQL.ExecuteSql(strql);
            strql = "delete from Bus_PD where sheetid = '" + sheetid + "'";
            return DbHelperSQL.ExecuteSql(strql);


        }


        #endregion

    }
}
