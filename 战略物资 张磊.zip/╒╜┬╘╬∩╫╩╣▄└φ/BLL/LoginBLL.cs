﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DBUtility;
using System.Data.SqlClient;
namespace BLL
{
    public class LoginBLL
    {
        /// <summary>
        /// 根据用户名获取用户资料
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public DataSet CheckLoginUser(string userName)
        {
            DataSet ds = new DataSet();
            string strSQL = "";
            strSQL = string.Format("select * from Bas_Users where UserCode='{0}'", userName);
            return DbHelperSQL.Query(strSQL);
        }
       
        /// <summary>
        /// 获取菜单模块
        /// </summary>
        /// <param name="role_NO"></param>
        /// <returns></returns>
        public DataSet GetMenu(string role_NO)
        {
            DataSet ds = new DataSet();
            string strSQL = "";
            strSQL = string.Format("SELECT * FROM Sys_Right ORDER BY Rightid", role_NO);
            ds = DbHelperSQL.Query(strSQL);
            //  ds = GetList("菜单模块", role_NO,"");
            if (ds != null)
            {

                return ds;
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// 获取列表内容
        /// </summary>
        /// <param name="moduleName"></param>
        /// <param name="moduleValue"></param>
        /// <returns></returns>
        public static DataSet GetRight()
        {
            DataSet ds = new DataSet();
            string s = " SELECT * from Sys_Right order by rightid";

            ds = DbHelperSQL.Query(s);
            if (ds.Tables[0].Rows.Count > 0)
            {
                return ds;
            }
            else
            {
                return null;
            }
        }

       
        /// <summary>
        /// 存储过程参数
        /// </summary>
        /// <param name="moduleName">模块名</param>
        /// <param name="moduleValue">模块值</param>
        /// <returns></returns>
        public static IDataParameter[] DataParm(string moduleName, string moduleValue, string isCHA)
        {
            SqlParameter sqlparm1 = new SqlParameter();
            sqlparm1.Value = moduleName;
            sqlparm1.DbType = DbType.String;
            sqlparm1.ParameterName = "@ModuleName";

            SqlParameter sqlparm2 = new SqlParameter();
            sqlparm2.Value = moduleValue;
            sqlparm2.DbType = DbType.String;
            sqlparm2.ParameterName = "@ModuleValue";

            SqlParameter sqlparm3 = new SqlParameter();
            sqlparm3.Value = isCHA;
            sqlparm3.DbType = DbType.String;
            sqlparm3.ParameterName = "@IsCHA";
            IDataParameter[] parameters = new IDataParameter[] { sqlparm1, sqlparm2, sqlparm3 };
            return parameters;
        }

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="userPassword"></param>
        /// <returns></returns>
        public static bool UpdatePassword(string userNo, string userPassword)
        {
            string strSQL = "";
            strSQL = string.Format("update BAS_Users set PassWord='{0}' where UserCode='{1}'", userPassword, userNo);
            if (DbHelperSQL.ExecuteSql(strSQL) > 0)
            {
                return true;
            }
            else
            {
                return true;
            }
        }
    }
}
