﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using DBUtility;
using System.Data.SqlClient;
using Model;

namespace BLL
{
    public class BasBLL
    {
        public bool CheckVaccineNew(string code, string name)
        {
            string strsql = "select count(*) from bas_Vaccine where VaccineCode ='" + code + "' or Name ='" + name + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public bool CheckVaccineOld(string code, string name, string oldcode)
        {
            string strsql = @"select count(*) from bas_Vaccine where (VaccineCode ='" + code + "' or Name ='" + name + "') and VaccineCode<>'" + oldcode + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public int Vaccine_Insert(Bas_Vaccine vaccine)
        {
            DbHelperSQL.ExecuteSql("delete from bas_Vaccine where VaccineCode='"+vaccine.VaccineCode+"'");

            string strsql=@"insert into bas_Vaccine values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','{13}')";
            strsql = string.Format(strsql,vaccine.VaccineCode,vaccine.Name,vaccine.ShortName,vaccine.ProducterID,vaccine.ProductAddress,
                vaccine.Spec,vaccine.Contents,vaccine.Valid,vaccine.TypeName,vaccine.KindName,vaccine.NormalReaction,vaccine.AbnormalReaction,
                vaccine.Precautions,vaccine.Note);
            return DbHelperSQL.ExecuteSql(strsql);

        }
        public int Vaccine_Del(Bas_Vaccine vaccine)
        {
           return DbHelperSQL.ExecuteSql("delete from bas_Vaccine where VaccineCode='" + vaccine.VaccineCode + "'");
        }
        public DataSet QueryVaccine(string code, string name)
        {
            string strsql = @"select * from bas_Vaccine where 1=1 ";
            if (code != "")
            {
                strsql += " and VaccineCode like '%" + code + "%'";
            }
            if (name != "")
            {
                strsql += " and name like '%" + name + "%'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet QueryVaccine(string code)
        {
            string strsql = @"select * from bas_Vaccine where 1=1 ";
            if (code != "")
            {
                strsql += " and VaccineCode = '" + code + "'";
            }
        
            return DbHelperSQL.Query(strsql);
        }

        public bool CheckVenderNew(string code, string name)
        {
            string strsql = "select count(*) from bas_Vender where VenderCode ='" + code + "' or Name ='" + name + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public bool CheckVenderOld(string code, string name, string oldcode)
        {
            string strsql = @"select count(*) from bas_Vender where (VenderCode ='" + code + "' or Name ='" + name + "') and VenderCode<>'" + oldcode + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public int Vender_Insert(Bas_Vender vaccine)
        {
            DbHelperSQL.ExecuteSql("delete from bas_Vender where VenderCode='" + vaccine.VenderCode + "'");

            string strsql = @"insert into bas_Vender values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')";
            strsql = string.Format(strsql, vaccine.VenderCode, vaccine.Name, vaccine.ShortName, vaccine.Address, vaccine.PerSen,
                vaccine.License, vaccine.Note );
            return DbHelperSQL.ExecuteSql(strsql);

        }
        public int Vender_Del(Bas_Vender vaccine)
        {
            return DbHelperSQL.ExecuteSql("delete from bas_Vender where VenderCode='" + vaccine.VenderCode + "'");
        }
        public DataSet QueryVender(string code, string name)
        {
            string strsql = @"select * from bas_Vender where 1=1 ";
            if (code != "")
            {
                strsql += " and VenderCode like '%" + code + "%'";
            }
            if (name != "")
            {
                strsql += " and name like '%" + name + "%'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet QueryVender(string code)
        {
            string strsql = @"select * from bas_Vender where 1=1 ";
            if (code != "")
            {
                strsql += " and VenderCode = '" + code + "'";
            }

            return DbHelperSQL.Query(strsql);
        }

        public bool CheckCustomerNew(string code, string name)
        {
            string strsql = "select count(*) from bas_Customer where CustomerCode ='" + code + "' or Name ='" + name + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public bool CheckCustomerOld(string code, string name,string oldcode)
        {
            string strsql = @"select count(*) from bas_Customer where (CustomerCode ='" + code + "' or Name ='" + name + "') and CustomerCode<>'" + oldcode + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public int Customer_Insert(Bas_Customer vaccine)
        {
            DbHelperSQL.ExecuteSql("delete from bas_Customer where CustomerCode='" + vaccine.CustomerCode + "'");

            string strsql = @"insert into bas_Customer values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}')";
            strsql = string.Format(strsql, vaccine.CustomerCode, vaccine.Name, vaccine.ShortName, vaccine.Address, vaccine.PerSen,
                vaccine.License, vaccine.Note);
            return DbHelperSQL.ExecuteSql(strsql);

        }
        public int Customer_Del(Bas_Customer vaccine)
        {
            return DbHelperSQL.ExecuteSql("delete from bas_Customer where CustomerCode='" + vaccine.CustomerCode + "'");
        }
        public DataSet QueryCustomer(string code, string name)
        {
            string strsql = @"select * from bas_Customer where 1=1 ";
            if (code != "")
            {
                strsql += " and CustomerCode like '%" + code + "%'";
            }
            if (name != "")
            {
                strsql += " and name like '%" + name + "%'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet QueryCustomer(string code)
        {
            string strsql = @"select * from bas_Customer where 1=1 ";
            if (code != "")
            {
                strsql += " and CustomerCode = '" + code + "'";
            }

            return DbHelperSQL.Query(strsql);
        }

        public bool CheckGoodsNew(string code, string name)
        {
            string strsql = "select count(*) from bas_Goods where GoodsCode ='" + code + "' or GoodsName ='" + name + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public bool CheckGoodsOld(string code, string name, string oldcode)
        {
            string strsql = @"select count(*) from bas_Goods where (GoodsCode ='" + code + "' or GoodsName ='" + name + "') and GoodsCode<>'" + oldcode + "'";
            return DbHelperSQL.Exists(strsql);
        }
        public int Goods_Insert(Bas_Goods vaccine)
        {
            DbHelperSQL.ExecuteSql("delete from bas_Goods where GoodsCode='" + vaccine.GoodsCode + "'");

            string strsql = @"insert into bas_Goods values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}')";
            strsql = string.Format(strsql, vaccine.GoodsCode, vaccine.GoodsName, vaccine.ShortName, vaccine.EffectiveMonth
                , vaccine.ProductName,vaccine.Note,vaccine.StockLimit,vaccine.StockCaps,vaccine.Price);
            return DbHelperSQL.ExecuteSql(strsql);

        }
        public int Goods_Del(Bas_Goods vaccine)
        {
            return DbHelperSQL.ExecuteSql("delete from bas_Goods where GoodsCode='" + vaccine.GoodsCode + "'");
        }
        public DataSet QueryGoods(string code, string name)
        {
            string strsql = @"select * from bas_Goods where 1=1 ";
            if (code != "")
            {
                strsql += " and GoodsCode like '%" + code + "%'";
            }
            if (name != "")
            {
                strsql += " and GoodsName like '%" + name + "%'";
            }
            return DbHelperSQL.Query(strsql);
        }
        public DataSet QueryGoods(string code)
        {
            string strsql = @"select * from bas_Goods where 1=1 ";
            if (code != "")
            {
                strsql += " and GoodsCode = '" + code + "'";
            }

            return DbHelperSQL.Query(strsql);
        }
        public DataSet QueryGoodsStock(string code)
        {
            string strsql = @"select a.VaccineCode,e.GoodsName,BatchID,convert(varchar(10),ProductDate,120) as ProductDate,Qty
from dbo.bus_StockBatch a 
inner join dbo.bas_Goods e on a.VaccineCode = e.GoodsCode 
where 1=1 ";
            if (code != "")
            {
                strsql += " and a.VaccineCode = '" + code + "'";
            }

            return DbHelperSQL.Query(strsql);
        }


        /// <summary>
        /// 获得单据编号
        /// </summary>
        /// <param name="Module_Type">类别</param>
        /// <returns>单据编号</returns>
        public string GetSheetID(string BatchType)
        {

            string DateString = DbHelperSQL.GetSingle("select substring(convert(varchar(100), getdate(), 112),3,4)").ToString();

            string strsql = "select isnull(BatchValue,0) as BatchValue  from Sys_Batch where BatchType='" + BatchType + "'";
            strsql = strsql + " and BatchDate='" + DateString.Trim() + "'";
            string A = Convert.ToString(DbHelperSQL.GetSingle(strsql));
            Int32 Value;
            if (A != "")
            {
                Value = Convert.ToInt32(A);
                Value = Value + 1;
                string UpdateSql = "update Sys_Batch set BatchValue=" + Value + " ";
                UpdateSql = UpdateSql + " where BatchType='" + BatchType + "' and BatchDate='" + DateString + "'";
                DbHelperSQL.ExecuteSql(UpdateSql);
                string Number = Convert.ToString(Value);
                int IDlen = ("0000" + Number).Length;
                string ID = ("0000" + Number).Substring(IDlen - 5, 5);
                ID = BatchType.Trim() + DateString.Trim() + ID;
                return ID;
            }
            else
            {
                string UpdateSql = "insert into Sys_Batch(BatchType,BatchDate,BatchValue) values('" + BatchType + "','" + DateString.Trim() + "',1)";
                DbHelperSQL.ExecuteSql(UpdateSql);
                return BatchType.Trim() + DateString.Trim() + "00001";
            }
        }
        public string GetUserID(string BatchType)
        {
            string strsql = "select isnull(BatchValue,0) as BatchValue  from Sys_Batch where BatchType='" + BatchType + "'";
            string A = Convert.ToString(DbHelperSQL.GetSingle(strsql));
            Int32 Value;
            if (A != "")
            {
                Value = Convert.ToInt32(A);
                Value = Value + 1;
                string UpdateSql = "update Sys_Batch set BatchValue=" + Value + " ";
                UpdateSql = UpdateSql + " where BatchType='" + BatchType +"'";
                DbHelperSQL.ExecuteSql(UpdateSql);
                string Number = Convert.ToString(Value);
                int IDlen = ("0000" + Number).Length;
                string ID = ("0000" + Number).Substring(IDlen - 2, 2);
                ID = BatchType.Trim() + ID;
                return ID;
            }
            else
            {
                string UpdateSql = "insert into Sys_Batch(BatchType,BatchDate,BatchValue) values('" + BatchType + "','00',1)";
                DbHelperSQL.ExecuteSql(UpdateSql);
                return BatchType.Trim() + "01";
            }
        }

        public int UpdatePassWord(string usercode,string newpassword)
        {
            string strsql = "update bas_Users set passwrod = '"+newpassword+"' where usercode ='"+usercode+"'";
            return DbHelperSQL.ExecuteSql(strsql);

        }

        public int Insert_User(string usercode,string name,string password,string email,string phone,string note)
        {
            string strsql = @"insert into bas_Users([UserCode],[UserName],[PassWord],[Del],Email,Phone,Note) 
            values('{0}','{1}','{2}',0,'{3}','{4}','{5}')";
            strsql = string.Format(strsql,usercode, name, password, email, phone, note);
            return DbHelperSQL.ExecuteSql(strsql);
        }
        public int Update_User(string usercode, string name, string password, string email, string phone, string note)
        {
            string strsql = @"update bas_Users set UserName='{1}',PassWord='{2}',Email='{3}',phone='{4}',note='{5}'
where UserCode = '{0}'";
            strsql = string.Format(strsql, usercode, name, password, email, phone, note);
            return DbHelperSQL.ExecuteSql(strsql);
        }
        public int Del_User(string usercode)
        {
            string strsql = "update bas_Users set del = 1 where usercode = '"+usercode+"'";
            return DbHelperSQL.ExecuteSql(strsql);
        }

        public DataSet QueryUser(string usercode, string name)
        {
            string strsql = @"select * from bas_Users where 1=1 ";
            if(usercode !="")
            {
                strsql += " and usercode like '%" + usercode + "%'";
            }
            if (name != "")
            {
                strsql += " and UserName like '%" + name + "%'";
            }
            strsql = strsql + " and del=0 ";
            return DbHelperSQL.Query(strsql);


        }



    }
}
