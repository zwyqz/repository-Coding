﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;


    public static class BindTreeView
    {

        public static void BindTree(TreeView treeview, DataSet ds, String[] text, String value)
        {
            treeview.Nodes.Clear();

            if (ds != null)
            {
             
                foreach (DataRow dr in ds.Tables[0].Select("[Parent]='00000000-0000-0000-0000-000000000000'"))
                {
                    TreeNode Node = new TreeNode();
                    Node.Text = "";
                    foreach (string item in text)
                    {
                        Node.Text = Node.Text + dr[item].ToString() + " ";
                    }
                    Node.Text = Node.Text.ToString().Substring(0, Node.Text.Length - 1);
                    Node.Tag = dr;
                    treeview.Nodes.Add(Node);

                    AddTree(dr[value].ToString(), Node, ds, text, value);
                }
            }
            treeview.ExpandAll();
            //tvMain.ExpandDepth = 0;
        }

        private static void AddTree(string ParentID, TreeNode pNode, DataSet ds, String[] text, String value)
        {
            //DataView DataView_Tree = new DataView(ds.Tables[0]);
            //DataView_Tree.RowFilter = " [Parent]='" + ParentID + "'";
            DataRow[] dr = ds.Tables[0].Select(" [Parent]='" + ParentID + "'");

            foreach (DataRow row in dr)
            {
                TreeNode Node = new TreeNode();
                Node.Text = "";
                foreach (string item in text)
                {
                    Node.Text = Node.Text + row[item].ToString() + " ";
                }
                Node.Text = Node.Text.ToString().Substring(0, Node.Text.Length - 1);
                Node.Tag = row;
                pNode.Nodes.Add(Node);
                AddTree(row[value].ToString(), Node, ds, text, value);   //再次递归 
               
            }
        }

        public static void setExpandNode(TreeView treeview, string currentId)
        {
            foreach (TreeNode node in treeview.Nodes)
            {
                node.Expand();

                if (!string.IsNullOrEmpty(currentId))
                {
                    if (Guid.Parse(node.Tag.ToString()) == Guid.Parse(currentId))
                    {
                        if (node.Parent != null)
                        {
                            //node.Parent.Expanded = true;
                            TreeNode treenode;
                            treenode = node.Parent;
                            treenode.Expand();

                            while (treenode.Parent != null)
                            {
                                treenode = treenode.Parent;
                                treenode.Expand();
                            }
                        }
                        treeview.SelectedNode = node;
                    }
                    else
                    {
                        treeview.SelectedNode = node;
                    }
                }
                //setExpandChildNode(node, currentId);
            }
        }

        private static void setExpandChildNode(TreeNode node)
        {
            foreach (TreeNode childCode in node.Nodes)
            {
                childCode.Expand();
                 
                setExpandChildNode(childCode);
            }



        }



    }



