﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Windows.Forms;


    public static class BindGridView
    {
        public static void Bind(DataGridView gv,DataSet ds )
        {
            gv.DataSource = ds.Tables[0];

        }

        public static void AddRows(DataGridView gv, DataSet ds,string[] s)
        {
            //DataTable dt=new DataTable();
            //dt=ds.Tables[0];
            //DataRow row = new DataRow[s.Length];

            //foreach (DataRow item in ds.Tables[0])
            //{

            //    foreach (string sitem in s)
            //    {
            //        item[sitem]
            //    }
            //    gv.Rows.Add();
            //}
            

        }

        /// <summary> 
        /// 方法实现把dgv里的数据完整的复制到一张内存表 
        /// </summary> 
        /// <param name="dgv">dgv控件作为参数 </param> 
        /// <returns>返回临时内存表 </returns> 
        public static DataTable GetDgvToTable(DataGridView dgv)
        {
            DataTable dt = new DataTable();
            for (int count = 0; count < dgv.Columns.Count; count++)
            {
                DataColumn dc = new DataColumn(dgv.Columns[count].Name.ToString());
                dt.Columns.Add(dc);
            }
            for (int count = 0; count < dgv.Rows.Count; count++)
            {
                DataRow dr = dt.NewRow();
                if (Convert.ToString(dgv.Rows[count].Cells[0].Value) != "")
                {
                    for (int countsub = 0; countsub < dgv.Columns.Count; countsub++)
                    {
                        dr[countsub] = Convert.ToString(dgv.Rows[count].Cells[countsub].Value);
                    }
                    dt.Rows.Add(dr);
                }

            }
            return dt;
        }


    }

