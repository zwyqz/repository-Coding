﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;


public class ClassMain
{
    //public static SqlConnection Cnn;
    public static string connectionString = "server=.;database=Materials;UID=sa;PassWord=1qazxsw2#";

    public static String ProgMainName = "战略物资管理系统";
    public struct SystemDesk
    {
        public Int32 WorkAreaHeight;
        public Int32 WorkAreaWidth;
    }
    public static SystemDesk SD;
    public enum ShuXing
    {
        Height,
        Width
    }

    public struct Userlogintype
    {
        public String UserCode;//用户ID
        public String UserName;
        public String Login_date;
        public String RoleCode;
    }
    public static Userlogintype UL;







}
