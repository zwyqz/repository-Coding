﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


    public static class Alter
    {
        public static void ShowError(string text)
        {
            MessageBox.Show(text,"操作",MessageBoxButtons.OK,MessageBoxIcon.Error);
        }
        public static void ShowWarning(string text )
        {
            MessageBox.Show(text, "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        public static void ShowNone(string text )
        {
            MessageBox.Show(text, "", MessageBoxButtons.OK, MessageBoxIcon.None);
        }
        public static void ShowOK(string text )
        {
            MessageBox.Show(text, "确认", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
        }
        public static bool ShowChoose(string text)
        {
            if (MessageBox.Show(text, "确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No)
            {
                return false;
            }
            else
            {
                return true;
            }

        }
        public static void ShowSystemError()
        {
            MessageBox.Show("执行错误请检查网络并联系管理员", "系统错误", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

    }

