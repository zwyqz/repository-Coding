﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Data;

    public static class Export
    {
        /// <summary>
        /// 导出csv
        /// </summary>
        /// <param name="dv"></param>
        /// <param name="strFileName"></param>
        public static void ExportCSV(DataGridView dv,string strFileName)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Execl files (*.xls)|*.xls";
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.FileName = strFileName;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = true;
            saveFileDialog.Title = "导出Excel文件到";

            saveFileDialog.ShowDialog();
            if (saveFileDialog.FileName != "")
            {
                Stream myStream;
                myStream = saveFileDialog.OpenFile();
                StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.UTF32);
                //StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.GetEncoding("gb2312"));
                string str = "";


                //写标题  
                for (int i = 0; i < dv.ColumnCount; i++)
                {
                    if (i > 0)
                    {
                        str += "\t";
                    }
                    str += dv.Columns[i].HeaderText;
                }

                sw.WriteLine(str);
                //sw.WriteLine("按出库单统计一段时间内车型颜色数量走势");
                //写内容 
                for (int j = 0; j < dv.Rows.Count; j++)
                {
                    string tempStr = "";
                    for (int k = 0; k < dv.Columns.Count; k++)
                    {
                        if (k > 0)
                        {
                            tempStr += "\t";
                        }
                        tempStr += Convert.ToString(dv.Rows[j].Cells[k].Value);
                    }
                    sw.WriteLine(tempStr);
                }
                sw.Close();
                myStream.Close();
            }
        }
        /// <summary>
        /// 生成excel导出
        /// </summary>
        /// <param name="dv"></param>
        /// <param name="filename"></param>
        public static void ExportExcel(DataGridView dv, string filename)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Execl files (*.xls)|*.xls";
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = true;
            saveFileDialog.Title = "Export Excel File To";
            //saveFileDialog1.ShowDialog();
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string strName = saveFileDialog.FileName;
                object missing = System.Reflection.Missing.Value;
                Excel.Application xlApp = new Excel.Application();
                if (xlApp == null)
                {
                    //clsLog.m_CreateErrorLog("无法创建Excel对象，可能计算机未安装Excel", "", "");
                    return;
                }
                //創建Excel對象
                Excel.Workbooks workbooks = xlApp.Workbooks;
                Excel.Workbook workbook = workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
                //Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Worksheets[1];//取得sheet1
                Excel.Worksheet worksheet = null;

                worksheet = (Excel.Worksheet)workbook.Worksheets.Add(Type.Missing, Type.Missing, 1, Type.Missing);
                worksheet.Name = filename;
                for (int i = 1; i <= dv.Columns.Count;i++ )
                {
                    worksheet.Cells[1, i] = dv.Columns[i - 1].HeaderText;
                    //将DataTable赋值给excel
                    for (int k = 1; k < dv.Rows.Count + 1; k++)
                    {
                        worksheet.Cells[k + 1, i] = "'" + dv.Rows[k - 1].Cells[i-1].Value;
                        
                    }
                }

                //保存excel文件
                workbook.SaveCopyAs(strName);
                //关闭文件
                workbook.Close(false, missing, missing);
                //退出excel
                //app.Quit();
                
                Alter.ShowOK("导出成功");
            }
        }

        public static void ExportCSV(DataTable dv, string strFileName)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Execl files (*.xls)|*.xls";
            saveFileDialog.FilterIndex = 0;
            saveFileDialog.FileName = strFileName;
            saveFileDialog.RestoreDirectory = true;
            saveFileDialog.CreatePrompt = true;
            saveFileDialog.Title = "导出Excel文件到";

            saveFileDialog.ShowDialog();
            if (saveFileDialog.FileName != "")
            {
                Stream myStream;
                myStream = saveFileDialog.OpenFile();
                StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.UTF32);
                //StreamWriter sw = new StreamWriter(myStream, System.Text.Encoding.GetEncoding("gb2312"));
                string str = "";

                //写标题  
                str ="物资编码" + "\t" + "名称" + "\t"+"库存数量"+ "\t"+"采购数量"+ "\t"+"库存下限"+ "\t" +"库存上限"+"\t";
                sw.WriteLine(str);

          
                //写内容 
                for (int j = 0; j < dv.Rows.Count; j++)
                {
                    string tempStr = "";
                    for (int k = 0; k < dv.Columns.Count; k++)
                    {
                        if (k > 0)
                        {
                            tempStr += "\t";
                        }
                        tempStr += Convert.ToString(dv.Rows[j].ItemArray[k]);
                    }
                    sw.WriteLine(tempStr);
                }
                sw.Close();
                myStream.Close();
            }
        }
    }



