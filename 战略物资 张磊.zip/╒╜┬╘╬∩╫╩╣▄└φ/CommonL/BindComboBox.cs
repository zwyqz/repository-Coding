﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;


    public class BindComboBox
    {
        /// <summary>
        /// combobox绑定下拉
        /// </summary>
        /// <param name="cb">ComboBox控件</param>
        /// <param name="sql">查询语句</param>
        /// <param name="DataVlaue">保存值</param>
        /// <param name="DataText">显示值</param>
        /// <param name="defvalue">默认行填充方式，暂无用</param>
        public static void cmb_drop(ComboBox cb, DataSet ds, String DataVlaue, String DataText, string defvalue)
        {
            DataTable dt = new DataTable();
            dt = ds.Tables[0];// SqlHelper.ExecuteSelectSql(sql);

            //插入一个默认选项
            if (defvalue!="")
            {
                DataRow dr = dt.NewRow();
                dr[DataVlaue] = DBNull.Value;//这个值可以自己需要设置，但不要和已经存在ID重复，所以最好设置特殊一点
                dr[DataText] = defvalue;
                dt.Rows.InsertAt(dr, 0);//指定起始位置插入
            }
            cb.DataSource = dt;
            cb.DisplayMember = DataText;
            cb.ValueMember = DataVlaue;
            cb.SelectedIndex = -1;
        }

    }


