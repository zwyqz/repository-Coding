﻿using System;
using System.Data;
using System.Web.UI.WebControls;



namespace CommonL
{
    public class Other
    {
        /// <summary>
        /// 绑定下拉列表
        /// </summary>
        /// <param name="sl"></param>
        /// <param name="ds"></param>
        /// <param name="DataVlaue"></param>
        /// <param name="DataText"></param>
        /// <param name="defvalue"></param>
        public static void ddl_null(DropDownList sl, DataSet ds, String DataVlaue, String DataText, String defvalue)
        {
            sl.DataSource = ds;
            sl.DataTextField = DataText;
            sl.DataValueField = DataVlaue;
            sl.DataBind();

            if (defvalue == "choose")
            {
                ListItem li = new ListItem("请选择...", "");
                sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "all")
            {
                ListItem li = new ListItem("全部", "%");
                sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "nothing")
            {
                // ListItem li = new ListItem("", "");
                // sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "null")
            {
                ListItem li = new ListItem("", "");
                sl.Items.Insert(0, li);//插入到指定位置
            }

            //if (defvalue != null && defvalue != "")
            //{
            //    sl.SelectedIndex = sl.Items.IndexOf(sl.Items.FindByValue(defvalue));
            //}

        }
        public static void ddl_null(DropDownList sl, DataTable ds, String DataVlaue, String DataText, String defvalue)
        {
            sl.DataSource = ds;
            sl.DataTextField = DataText;
            sl.DataValueField = DataVlaue;
            sl.DataBind();

            if (defvalue == "choose")
            {
                ListItem li = new ListItem("请选择...", "");
                sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "all")
            {
                ListItem li = new ListItem("全部", "%");
                sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "nothing")
            {
                // ListItem li = new ListItem("", "");
                // sl.Items.Insert(0, li);//插入到指定位置
            }
            if (defvalue == "null")
            {
                ListItem li = new ListItem("", "");
                sl.Items.Insert(0, li);//插入到指定位置
            }

            //if (defvalue != null && defvalue != "")
            //{
            //    sl.SelectedIndex = sl.Items.IndexOf(sl.Items.FindByValue(defvalue));
            //}

        }




    }
}
