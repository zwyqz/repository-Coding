﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using Model;

namespace 战略物资管理
{
    public partial class Frm_Customer : Form
    {
        BasBLL bll = new BasBLL();
        string m_sheetid = "";
        public Frm_Customer()
        {
            InitializeComponent();
        }

        private void Frm_Customer_Load(object sender, EventArgs e)
        {
            BindDDData();
        }
        private void BindDDData()
        {
            DataTable dt = bll.QueryCustomer("","").Tables[0];
            dataGridView1.DataSource = dt;

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            ADD();
        }
        private void ADD()
        {
            m_sheetid = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox1.Focus();
        }
        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            if(dataGridView1.CurrentCell!= null)
            {
                //MessageBox.Show("新del");
                Bas_Customer Vaccine = new Bas_Customer();
                Vaccine.CustomerCode = m_sheetid;
                bll.Customer_Del(Vaccine);
                BindDDData();
                ADD();
            }
            
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if(dataGridView1.CurrentCell!= null)
            {
                int a = e.RowIndex;
                m_sheetid = dataGridView1.Rows[a].Cells[0].Value.ToString();
                textBox1.Text = Convert.ToString(dataGridView1.Rows[a].Cells[0].Value);
                textBox1.Text = Convert.ToString(dataGridView1.Rows[a].Cells[0].Value);
                textBox2.Text = Convert.ToString(dataGridView1.Rows[a].Cells[1].Value);
                textBox3.Text = Convert.ToString(dataGridView1.Rows[a].Cells[2].Value);
                textBox4.Text = Convert.ToString(dataGridView1.Rows[a].Cells[3].Value);
                textBox5.Text = Convert.ToString(dataGridView1.Rows[a].Cells[4].Value);
                textBox6.Text = Convert.ToString(dataGridView1.Rows[a].Cells[5].Value);
                textBox7.Text = Convert.ToString(dataGridView1.Rows[a].Cells[6].Value);
                textBox1.Focus();
            }
        }

        //刷新
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            BindDDData();
            ADD();
        }
        //保存
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if ( textBox2.Text.Trim()=="")
            {
                MessageBox.Show("名称为必填项");
                return;
            }
            Bas_Customer vaccine = new Bas_Customer();
            vaccine.CustomerCode = textBox1.Text.Trim();
            vaccine.Name = textBox2.Text.Trim();
            vaccine.ShortName = textBox3.Text.Trim();
            vaccine.Address = textBox4.Text.Trim();
            vaccine.PerSen = textBox5.Text.Trim();
            vaccine.License = textBox6.Text.Trim();
            vaccine.Note = textBox7.Text.Trim();

            
            if (m_sheetid == "")
            {
                //b = bll.CheckCustomerNew(vaccine.CustomerCode, vaccine.Name);
                vaccine.CustomerCode = bll.GetSheetID("C");
            }
            else
            {
                
                //b = bll.CheckCustomerOld(vaccine.CustomerCode, vaccine.Name, m_sheetid);
            }
            bll.Customer_Insert(vaccine);

            BindDDData();
            ADD();
            

        }




    }
}
