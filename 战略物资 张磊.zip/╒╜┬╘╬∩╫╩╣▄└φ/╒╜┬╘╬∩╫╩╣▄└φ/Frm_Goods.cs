﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using Model;

namespace 战略物资管理
{
    public partial class Frm_Goods : Form
    {
        BasBLL bll = new BasBLL();
        string m_sheetid = "";

        public Frm_Goods()
        {
            InitializeComponent();
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            ADD();
        }
        private void ADD()
        {
            m_sheetid = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";

            textBox1.Focus();
        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentCell != null)
            {
                //MessageBox.Show("新del");
                Bas_Goods Vaccine = new Bas_Goods();
                Vaccine.GoodsCode = m_sheetid;
                bll.Goods_Del(Vaccine);
                BindDDData();
                ADD();
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            BindDDData();
            ADD();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() == "" || textBox4.Text.Trim() == "" || textBox7.Text.Trim() == ""
                || textBox8.Text.Trim() == ""
                || textBox9.Text.Trim() == "")
            {
                MessageBox.Show("有必填项未填");
                return;
            }
            Bas_Goods vaccine = new Bas_Goods();
            vaccine.GoodsCode = textBox1.Text.Trim();
            vaccine.GoodsName = textBox2.Text.Trim();
            vaccine.ShortName = textBox3.Text.Trim();
            vaccine.EffectiveMonth =Convert.ToInt32(textBox4.Text.Trim());
            vaccine.ProductName = textBox5.Text.Trim();
            vaccine.Note = textBox6.Text.Trim();
            vaccine.StockLimit = Convert.ToInt32( textBox7.Text.Trim());
            vaccine.StockCaps = Convert.ToInt32(textBox8.Text.Trim());
            vaccine.Price = Convert.ToDecimal(textBox9.Text.Trim());

            
            if (m_sheetid == "")
            {
                vaccine.GoodsCode = bll.GetSheetID("G");
                //b = bll.CheckCustomerNew(vaccine.GoodsCode, vaccine.GoodsName);
            }
            else
            {
                //b = bll.CheckCustomerOld(vaccine.GoodsCode, vaccine.GoodsName, m_sheetid);
            }

               bll.Goods_Insert(vaccine);

                BindDDData();
                ADD();
           
        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell != null)
            {
                int a = e.RowIndex;
                m_sheetid = dataGridView1.Rows[a].Cells[0].Value.ToString();
                textBox1.Text = Convert.ToString(dataGridView1.Rows[a].Cells[0].Value);
                textBox1.Text = Convert.ToString(dataGridView1.Rows[a].Cells[0].Value);
                textBox2.Text = Convert.ToString(dataGridView1.Rows[a].Cells[1].Value);
                textBox3.Text = Convert.ToString(dataGridView1.Rows[a].Cells[2].Value);
                textBox4.Text = Convert.ToString(dataGridView1.Rows[a].Cells[3].Value);
                textBox5.Text = Convert.ToString(dataGridView1.Rows[a].Cells[4].Value);
                textBox6.Text = Convert.ToString(dataGridView1.Rows[a].Cells[5].Value);
                textBox7.Text = Convert.ToString(dataGridView1.Rows[a].Cells[6].Value);
                textBox8.Text = Convert.ToString(dataGridView1.Rows[a].Cells[7].Value);
                textBox9.Text = Convert.ToString(dataGridView1.Rows[a].Cells[8].Value);

                textBox1.Focus();
            }
        }

        private void Frm_Goods_Load(object sender, EventArgs e)
        {
            BindDDData();
        }
        private void BindDDData()
        {
            DataTable dt = bll.QueryGoods("", "").Tables[0];
            dataGridView1.DataSource = dt;

        }

    }
}
