﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace 战略物资管理
{
    public partial class Frm_Login : Form
    {
        LoginBLL m_LoginBLL = new LoginBLL();

        public Frm_Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();

        }

        private void Frm_Login_Load(object sender, EventArgs e)
        {
            txtUserName.Focus();
            txtUserName.Text = string.Empty;
            txtUserPwd.Text = string.Empty;
            lbl_message.Text = "";
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string strUserRealName = "";
            DataSet dsUser = new DataSet();
            

            strUserRealName = this.txtUserName.Text.ToString().Trim();
            dsUser = m_LoginBLL.CheckLoginUser(strUserRealName);

            if (dsUser != null)
            {
                if (dsUser.Tables[0].Rows.Count > 0)
                {
                    if (dsUser.Tables[0].Rows[0]["UserCode"].ToString() == strUserRealName)
                    {
                        DataRow dr = dsUser.Tables[0].Rows[0];
                        if (dr["PassWord"].ToString() == txtUserPwd.Text.ToString().Trim())
                        {
                            this.Hide();
                            ClassMain.UL.UserCode = dsUser.Tables[0].Rows[0]["UserCode"].ToString();
                            ClassMain.UL.UserName = dsUser.Tables[0].Rows[0]["UserName"].ToString();
                
                            Frm_Main frm = new Frm_Main();
                            frm.Show();
                        }
                        else
                        {
                            this.txtUserPwd.Focus();
                            lbl_message.Text = "密码错误";
                            return;
                        }
                    }
                }
            }
            else
            {
                this.txtUserPwd.Focus();
                lbl_message.Text = "用户名不存在"; 
                return;
            }


        }


    }
}
