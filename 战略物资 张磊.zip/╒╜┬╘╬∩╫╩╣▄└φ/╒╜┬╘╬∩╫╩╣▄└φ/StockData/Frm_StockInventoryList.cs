﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace PlatForm.StockData
{
    public partial class Frm_StockInventoryList : Form
    {
        BusBLL bll = new BusBLL();
        public Frm_StockInventoryList()
        {
            InitializeComponent();
        }

        private void Frm_StockInventoryList_Load(object sender, EventArgs e)
        {
            bind();
        }
        private void bind()
        {
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = bll.PD(textBox1.Text.Trim(), dateTimePicker1.Text).Tables[0];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bind();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(dataGridView1.CurrentCell!=null)
            {
                string sheetid = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString(); ;
                Frm_StockInventory frm = new Frm_StockInventory();
                frm.status = "edit";
                frm.sheetid = sheetid;
                frm.ShowDialog();
            
            }
            
        }


    }
}
