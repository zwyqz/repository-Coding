﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace 战略物资管理.StockData
{
    public partial class Frm_StockWaring2 : Form
    {
        public Frm_StockWaring2()
        {
            InitializeComponent();
        }

        private void Frm_StockWaring2_Load(object sender, EventArgs e)
        {
            binddate();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            binddate();
        }
        private void binddate()
        {
            BusBLL bll=new BusBLL();

            dataGridView1.DataSource = bll.YUJING().Tables[0];
            dataGridView2.DataSource = bll.YUJING2().Tables[0];

        }




    }
}
