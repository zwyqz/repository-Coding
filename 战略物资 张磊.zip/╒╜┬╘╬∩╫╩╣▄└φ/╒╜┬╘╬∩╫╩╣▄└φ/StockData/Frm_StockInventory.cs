﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace PlatForm.StockData
{
    public partial class Frm_StockInventory : Form
    {
        public string status = "";
        public string sheetid = "";
        BusBLL bll = new BusBLL();

        public Frm_StockInventory()
        {
            InitializeComponent();
        }

        private void Frm_StockInventory_Load(object sender, EventArgs e)
        {
            switch (status)
            {
                case "add": Add();
                    break;
                case "edit": Edit();
                    break;

                default:
                    break;
            }
        }
        private void Add()
        {
            sheetid = "";
            textBox1.Text = "";
            textBox2.Text = DateTime.Now.ToString();
           
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
            DataSet ds = bll.Stock();
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                dataGridView1.Rows.Add(dr[0],dr[1],dr[2],"","");
            }
            

        }
        private void Edit()
        {
            DataSet ds = new DataSet();
            ds = bll.PD(sheetid,  "");
            textBox1.Text = Convert.ToString(ds.Tables[0].Rows[0]["SheetID"]);
            textBox2.Text = Convert.ToString(ds.Tables[0].Rows[0]["PDDate"]);

            ds = bll.PDItem(sheetid);
            foreach (DataRow item in ds.Tables[0].Rows)
            {

                string GoodsCode = Convert.ToString(item["GoodsCode"]);
                string GoodsName = Convert.ToString(item["GoodsName"]);
                string ZS = Convert.ToString(item["ZS"]);
                string SP = Convert.ToString(item["SP"]);
                string CY = Convert.ToString(item["CY"]);

                dataGridView1.Rows.Add( GoodsCode, GoodsName, ZS, SP,CY);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Focus();
                dataGridView1.ClearSelection();
                dataGridView1.EndEdit();
                if (dataGridView1.Rows.Count <= 0)
                {
                    Alter.ShowOK("没有盘点明细");
                    return;
                }
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    DataGridViewRow dr = dataGridView1.Rows[i];
                    if (Convert.ToString(dr.Cells[3].Value) == "" || Convert.ToString(dr.Cells[4].Value) == "" )
                    {
                        Alter.ShowError("表体信息未填全！");
                        return ;
                    }
                }

                if (sheetid == "")
                {
                    BasBLL bas = new BasBLL();
                    sheetid = bas.GetSheetID("PD");
                }
                string PDDate = textBox2.Text.Trim();
                string editor = ClassMain.UL.UserName;

                bll.DeletePD(sheetid);

                bll.InsertPD(sheetid, PDDate, editor );

                string orderno = ""; string GoodsID = ""; string ZS = ""; string SP = ""; string CY = "";
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    orderno = (i + 1).ToString();
                    GoodsID = dataGridView1.Rows[i].Cells["编码"].Value.ToString();
                    ZS = dataGridView1.Rows[i].Cells["ZS"].Value.ToString();
                    SP = dataGridView1.Rows[i].Cells["SP"].Value.ToString();
                    CY = dataGridView1.Rows[i].Cells["CY"].Value.ToString();

                    bll.InsertPDItem(sheetid, orderno, GoodsID, ZS, SP,CY);
                }
                Alter.ShowOK("保存成功！");
                this.Close();
                //Add();


            }
            catch (Exception ex)
            {
                Alter.ShowError("保存失败！");
                //throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Export.ExportExcel(dataGridView1,"盘点结果");
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if(dataGridView1.CurrentCell.ColumnIndex==3)
            {
                string s = Convert.ToString(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[2].Value);
                s = s == "" ? "0" : s;
                string s1 = Convert.ToString(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[3].Value);
                s1 = s1 == "" ? "0" : s1;

                try
                {
                    int a = Convert.ToInt32(s);
                    int b = Convert.ToInt32(s1);
                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[4].Value = a - b;

                }
                catch (Exception ex)
                {
                    Alter.ShowError("请输入正确数字");
                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[2].Selected=true;
                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[3].Value = 0;

                    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[4].Value = "-"+s;


                }
            }
        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.CellStyle.BackColor = Color.Aquamarine;

            //try
            //{
            //    string s =Convert.ToString( dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[3].Value);
            //        s = s == "" ? "0" : s;
            //        string s1 = Convert.ToString(dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[4].Value);
            //        s1 = s1 == "" ? "0" : s;

            //    int a = Convert.ToInt32(s);
            //    int b = Convert.ToInt32(s1);
            //    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[5].Value = a - b;

            //}
            //catch (Exception ex)
            //{
            //    Alter.ShowError("请输入正确数字");
            //    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[4].Value = 0;
            //    dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[5].Value = 0;


            //}

        }



    }
}
