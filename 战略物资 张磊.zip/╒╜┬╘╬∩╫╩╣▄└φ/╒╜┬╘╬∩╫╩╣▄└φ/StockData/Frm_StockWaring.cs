﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace PlatForm.StockData
{
    public partial class Frm_StockWaring : Form
    {
        BusBLL bus = new BusBLL();
        public Frm_StockWaring()
        {
            InitializeComponent();
        }
        private void Frm_StockWaring_Load(object sender, EventArgs e)
        {
            //binddate();
           
        }
        private void binddate()
        {
            dataGridView1.DataSource = bus.Stock().Tables[0];

            for (int i = 0; i <= dataGridView1.Rows.Count-1; i++)
            {
                int a =Convert.ToInt32( dataGridView1.Rows[i].Cells["库存数量"].Value);
                int b = Convert.ToInt32(dataGridView1.Rows[i].Cells["库存下限"].Value);
                int c = Convert.ToInt32(dataGridView1.Rows[i].Cells["库存上限"].Value);

                if(a>c||a<b)
                {
                    dataGridView1.Rows[i].Cells["库存数量"].Style.ForeColor = Color.Red;
                }
            }

        }
        //查询
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            binddate();
        }
        //导出
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            Export.ExportCSV(dataGridView1, "库存查询");
        }



        private void dataGridView1_SortCompare(object sender, DataGridViewSortCompareEventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                int a = Convert.ToInt32(dataGridView1.Rows[i].Cells["库存数量"].Value);
                int b = Convert.ToInt32(dataGridView1.Rows[i].Cells["库存下限"].Value);
                int c = Convert.ToInt32(dataGridView1.Rows[i].Cells["库存上限"].Value);

                if (a > c || a < b)
                {
                    dataGridView1.Rows[i].Cells["库存数量"].Style.ForeColor = Color.Red;
                }
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = bus.CaiGouStock().Tables[0];
           

            Export.ExportCSV(dt, "采购计划");
        }





    }
}
