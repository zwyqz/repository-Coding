﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using 战略物资管理.BusData;
using 战略物资管理.BasData;
using PlatForm.StockData;
using TL;
using 战略物资管理.StockData;

namespace 战略物资管理
{
    public partial class Frm_Main : Form
    {
        public Frm_Main()
        {
            InitializeComponent();
        }


        private void Frm_Main_Load(object sender, EventArgs e)
        {

        }
        private void Frm_Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }



        
        /// <summary>
        /// 查询一个子窗体是否存在
        /// </summary>
        /// <param name="childFrmName"></param>
        /// <returns></returns>
        private bool checkChildFrmExist(string childFrmName)
        {
            foreach (Form childFrm in this.MdiChildren)
            {
                //用子窗体的Name进行判断，如果已经存在则将他激活
                if (childFrm.Name == childFrmName)
                {
                    if (childFrm.WindowState == FormWindowState.Minimized)
                        childFrm.WindowState = FormWindowState.Normal;
                    childFrm.Activate();
                    return true;
                }
            }
            return false;
        }

        private void 客户资料ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_Customer") == true)
            {
                return;
            }
            Frm_Customer frm = new Frm_Customer();
            frm.MdiParent = this;
            frm.Show();
        }
        private void 供货商ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_Vender") == true)
            {
                return;
            }
            Frm_Vender frm = new Frm_Vender();
            frm.MdiParent = this;
            frm.Show();
        }
        private void 物资ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_Goods") == true)
            {
                return;
            }
            Frm_Goods frm = new Frm_Goods();
            frm.MdiParent = this;
            frm.Show();
        }

        private void 入库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_RKItem") == true)
            {
                return;
            }
            Frm_RKItem frm = new Frm_RKItem();
            frm.MdiParent = this;
            frm.Show();
        }
        private void 入库查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_RKList") == true)
            {
                return;
            }
            Frm_RKList frm = new Frm_RKList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_RKItem") == true)
            {
                return;
            }
            Frm_RKItem frm = new Frm_RKItem();
            frm.MdiParent = this;
            frm.Show();
        }

        private void 出库ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_CKItem") == true)
            {
                return;
            }
            Frm_CKItem frm = new Frm_CKItem();
            frm.status = "add";
            frm.MdiParent = this;
            frm.Show();
        }

        private void 出库查询ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_CKList") == true)
            {
                return;
            }
            Frm_CKList frm = new Frm_CKList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_CKItem") == true)
            {
                return;
            }
            Frm_CKItem frm = new Frm_CKItem(); 
            frm.status = "add";
            frm.MdiParent = this;
            frm.Show();
        }

        private void 库存查询ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_StockWaring") == true)
            {
                return;
            }
            Frm_StockWaring frm = new Frm_StockWaring();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_StockWaring") == true)
            {
                return;
            }
            Frm_StockWaring frm = new Frm_StockWaring();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_StockInventory") == true)
            {
                return;
            }
            Frm_StockInventory frm = new Frm_StockInventory();
            frm.status = "add";
            frm.MdiParent = this;
            frm.Show();
        }

        private void 库存盘点ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_StockInventoryList") == true)
            {
                return;
            }
            Frm_StockInventoryList frm = new Frm_StockInventoryList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void 人员管理ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.checkChildFrmExist("Frm_userlist") == true)
            {
                return;
            }
            Frm_userlist frm = new Frm_userlist();
            frm.MdiParent = this;
            frm.Show();

            
        }

        private void 注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Frm_Login frm = new Frm_Login();
            frm.Show();
        }

        private void 库存预警ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (this.checkChildFrmExist("Frm_StockWaring2") == true)
            {
                return;
            }
            Frm_StockWaring2 frm = new Frm_StockWaring2();
            frm.MdiParent = this;
            frm.Show();

        }



    }
}
