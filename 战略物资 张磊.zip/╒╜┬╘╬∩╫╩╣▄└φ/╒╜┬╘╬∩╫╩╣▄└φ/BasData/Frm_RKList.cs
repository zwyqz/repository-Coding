﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace 战略物资管理.BusData
{
    public partial class Frm_RKList : Form
    {
        BasBLL bll = new BasBLL();
        BusBLL bus = new BusBLL();

        public Frm_RKList()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if(dataGridView1.CurrentCell !=null)
            {
                Frm_RKItem frm = new Frm_RKItem();
                frm.sheetid = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                frm.status = "edit";
                frm.Show();
            
            }
        }

        private void Frm_RKList_Load(object sender, EventArgs e)
        {
            BindComboBox.cmb_drop(comboBox1, bll.QueryVender("", ""), "VenderCode", "Name", "--请选择供货商--");
            comboBox1.SelectedIndex = 0;
            Bind();

        }
        //查询
        private void button1_Click(object sender, EventArgs e)
        {
            Bind();
        }
        private void Bind()
        {
            dataGridView1.AutoGenerateColumns = false;

            dataGridView1.DataSource = bus.View_Purchase(textBox1.Text, dateTimePicker1.Text, Convert.ToString(comboBox1.SelectedValue)).Tables[0];

        }



    }
}
