﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using Model;

namespace 战略物资管理.BasData
{
    public partial class Frm_CKItem : Form
    {
        public string status = "";
        public string sheetid = "";
        BasBLL bll = new BasBLL();
        BusBLL bus = new BusBLL();

        public Frm_CKItem()
        {
            InitializeComponent();
        }

        private void Frm_CKItem_Load(object sender, EventArgs e)
        {
            BindComboBox.cmb_drop(comboBox1, bll.QueryCustomer("", ""), "CustomerCode", "Name", "");
            comboBox1.SelectedIndex = 0;
            switch (status)
            {
                case "add": Add();
                    break;
                case "edit": Edit();
                    break;

                default:
                    break;
            }
        }
        private void Add()
        {
            sheetid = "";
            textBox1.Text = "";
            comboBox1.SelectedIndex = 0;
            textBox2.Text = "";
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
        }

        private void Edit()
        {
            DataSet ds = new DataSet();
            ds = bus.View_Sale(sheetid);
            textBox1.Text = Convert.ToString(ds.Tables[0].Rows[0]["SheetID"]);
            comboBox1.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["CustomerCode"]);
            dateTimePicker1.Text = Convert.ToString(ds.Tables[0].Rows[0]["EditDate"]);
            textBox2.Text = Convert.ToString(ds.Tables[0].Rows[0]["Note"]);

            foreach (DataRow item in ds.Tables[0].Rows)
            {

                string GoodsCode = Convert.ToString(item["VaccineCode"]);
                string GoodsName = Convert.ToString(item["GoodsName"]);
                string cost = Convert.ToString(item["BatchID"]);
                string cost1 = Convert.ToString(item["Price"]);
                string qty = Convert.ToString(item["Qty"]);
                AddRow(GoodsCode, GoodsName, cost, cost1, qty);
            }

        }


        public void AddRow(string GoodsCode, string GoodsName, string cost, string cost1, string qty)
        {
            dataGridView1.Rows.Add(GoodsCode, GoodsName, cost, cost1, qty);
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dataGridView1.CurrentCell == null)
            { return; }
            if (dataGridView1.CurrentCell.ColumnIndex == 0)
            {
                Frm_GoodsBox frm = new Frm_GoodsBox();
                frm.ShowDialog();
                if (frm.ReturnArray[0] == null)
                {
                    return;
                }
                else
                {
                    this.dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value = frm.ReturnArray[0].ToString();
                    this.dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[1].Value = frm.ReturnArray[1].ToString();
                    
                    SendKeys.Send("{Tab}");
                    SendKeys.Send("{Tab}");
                }
            
            }
            if (dataGridView1.CurrentCell.ColumnIndex == 2)
            {
                if(Convert.ToString( dataGridView1.CurrentRow.Cells[0].Value)=="")
                {
                    return;
                }
                Frm_GoodsBatchID frm = new Frm_GoodsBatchID();
                frm.ShowDialog();
                if (frm.ReturnArray[0] == null)
                {
                    return;
                }
                else
                {
                    this.dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[2].Value = frm.ReturnArray[2].ToString();
                    SendKeys.Send("{Tab}");
                    
                }

            }


        }
        //新增
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Add();
        }
        //删除
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (sheetid != "")
            {
                if (Alter.ShowChoose("确定删除数据？"))
                {
                    Bus_Sale Purchase = new Bus_Sale();
                    //删除
                    bus.Bus_Sale_Del(Purchase);
                    Add();
                }

            }
        }
        //保存
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Focus();
                dataGridView1.EndEdit();

                dataGridView1.ClearSelection();
                dataGridView1.Rows[0].Cells[0].Selected = true;

                if (UICheck())
                {
                    if (sheetid == "")
                    {
                        sheetid = bll.GetSheetID("CK");
                    }
                    Bus_Sale Purchase = new Bus_Sale();
                    Purchase.SheetID = sheetid;
                    Purchase.CustomerCode = comboBox1.SelectedValue.ToString();
                    Purchase.Editor = ClassMain.UL.UserCode;
                    Purchase.EditDate = DateTime.Now;
                    Purchase.Note = textBox2.Text.Trim();

                    bus.Bus_Sale_Del(Purchase);
                    bus.Bus_Sale_Insert(Purchase);
                    List<Bus_SaleItem> list = new List<Bus_SaleItem>();

                    for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                    {
                        Bus_SaleItem item = new Bus_SaleItem();
                        item.SheetID = sheetid;
                        item.OrderNo = (i + 1);
                        item.VaccineCode = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        item.BatchID = dataGridView1.Rows[i].Cells[2].Value.ToString();
                        item.Price = Convert.ToDecimal(dataGridView1.Rows[i].Cells[3].Value);
                        item.Qty = Convert.ToInt32(dataGridView1.Rows[i].Cells[4].Value);
                        list.Add(item);
                    }
                    bus.Bus_SaleItem_Insert(list);

                    Alter.ShowOK("保存成功！");
                    Add();
                }

            }
            catch (Exception ex)
            {
                Alter.ShowError("保存失败！");
                //throw;
            }
        }
        private bool UICheck()
        {

            #region 判断有效行数是否为0
            int rows = 0;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                string s = Convert.ToString(dr.Cells[0].Value);
                if (s != "")
                {
                    rows = rows + 1;
                }
            }
            if (rows == 0)
            {
                //MessageBox.Show("请填写表体信息！", ClassMain.ProgMainName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Alter.ShowError("请填写表体信息！");
                return false;
            }
            #endregion

            #region 判断表体信息是否填写完整
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                DataGridViewRow dr = dataGridView1.Rows[i];
                if (Convert.ToString(dr.Cells[1].Value) == "" || Convert.ToString(dr.Cells[2].Value) == ""
                    || Convert.ToString(dr.Cells[3].Value) == ""
                    || Convert.ToString(dr.Cells[4].Value) == "" || Convert.ToString(dr.Cells[0].Value) == "")
                {
                    Alter.ShowError("表体信息未填全！");
                    return false;
                }

            }


            #endregion
            return true;

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.ColumnIndex;
            int b = e.RowIndex;

            if (dataGridView1.Columns[a].Name == "售价")
            {
                try
                {
                    string cost = dataGridView1.Rows[b].Cells[a].Value.ToString();
                    decimal d = Convert.ToDecimal(cost);
                }
                catch (Exception ex)
                {
                    dataGridView1.Rows[b].Cells[a].Value = 0;
                    //Alter.ShowError("请检查输入数据格式");
                    //throw;
                }
            }
            if (dataGridView1.Columns[a].Name == "数量")
            {
                try
                {
                    string cost = dataGridView1.Rows[b].Cells[a].Value.ToString();
                    int d = Convert.ToInt32(cost);
                }
                catch (Exception ex)
                {
                    dataGridView1.Rows[b].Cells[a].Value = 0;
                    //Alter.ShowError("请检查输入数据格式");
                    //throw;
                }
            }
        }

       




    }
}
