﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;
using Model;

namespace 战略物资管理.BusData
{
    public partial class Frm_RKItem : Form
    {
        public string status = "";
        public string sheetid = "";
        BasBLL bll = new BasBLL();
        BusBLL bus = new BusBLL();
        private DateTimePicker dtp = new DateTimePicker();// DateTimeKind dtp = new DateTimeKind();


        public Frm_RKItem()
        {
            InitializeComponent();
        }

        private void Frm_RKItem_Load(object sender, EventArgs e)
        {
            dtp.Format = DateTimePickerFormat.Custom;//自动设置
            dtp.CustomFormat = "yyyy-MM-dd";//自定义格式 
            dtp.Text = DateTime.Now.ToString("yyyy-MM-dd");
            dtp.Value = System.DateTime.Now;
            dtp.ValueChanged += new EventHandler(dtp_ValueChanged); ;//new  dtp_ValueChanged
            this.dataGridView1.Controls.Add(dtp);
            dtp.Visible = false;

            BindComboBox.cmb_drop(comboBox1, bll.QueryVender("", ""), "VenderCode", "Name", "");
            comboBox1.SelectedIndex = 0;
            switch (status)
            {
                case "add": Add();
                    break;
                case "edit": Edit();
                    break;

                default:
                    break;
            }
            


        }
        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            dataGridView1.CurrentCell.Value = dtp.Text;
        }

        private void Add()
        {
            sheetid = "";
            textBox1.Text = "";
            comboBox1.SelectedIndex = 0;
            textBox2.Text = "";
            dataGridView1.DataSource = null;
            dataGridView1.Rows.Clear();
        }

        private void Edit()
        {
            DataSet ds = new DataSet();
            ds = bus.View_Purchase(sheetid);
            textBox1.Text = Convert.ToString(ds.Tables[0].Rows[0]["SheetID"]);
            comboBox1.SelectedValue = Convert.ToString(ds.Tables[0].Rows[0]["VenderCode"]);
            dateTimePicker1.Text = Convert.ToString(ds.Tables[0].Rows[0]["EditDate"]);
            textBox2.Text = Convert.ToString(ds.Tables[0].Rows[0]["Note"]);

            foreach (DataRow item in ds.Tables[0].Rows)
            {

                string GoodsCode = Convert.ToString(item["VaccineCode"]);
                string GoodsName = Convert.ToString(item["GoodsName"]);
                string Unit = Convert.ToString(item["ProductDate"]);
                string cost = Convert.ToString(item["BatchID"]);
                string cost1 = Convert.ToString(item["Cost"]);
                string qty = Convert.ToString(item["Qty"]);
                AddRow( GoodsCode, GoodsName, Unit, cost,cost1, qty);
            }

        }


        public void AddRow( string GoodsCode, string GoodsName, string Unit,string cost,string cost1,string qty )
        {
            dataGridView1.Rows.Add( GoodsCode, GoodsName, Unit, cost,cost1, qty);
        }
        
        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dataGridView1.CurrentCell == null)
            { return; }
            if (dataGridView1.CurrentCell.ColumnIndex != 0)
            { return; }
            Frm_GoodsBox frm = new Frm_GoodsBox();
            frm.ShowDialog();
            if (frm.ReturnArray[0] == null)
            {
                return;
            }
            else
            {
                this.dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value = frm.ReturnArray[0].ToString();
                this.dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[1].Value = frm.ReturnArray[1].ToString();
                SendKeys.Send("{Tab}");
                
            }


        }
        //新增
        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            Add();
        }
        //删除
        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if(sheetid != "")
            {
                if (Alter.ShowChoose("确定删除数据？"))
                {
                    Bus_Purchase Purchase = new Bus_Purchase();
                    //删除
                    bus.Bus_Purchase_Del(Purchase);
                    Add();
                }

            }
        }
        //保存
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Focus();
                dataGridView1.EndEdit();

                dataGridView1.ClearSelection();
                dataGridView1.Rows[0].Cells[0].Selected = true;

                if (UICheck())
                {
                    if(sheetid =="")
                    {
                        sheetid = bll.GetSheetID("RK");
                    }
                    Bus_Purchase Purchase = new Bus_Purchase();
                    Purchase.SheetID = sheetid;
                    Purchase.VenderCode = comboBox1.SelectedValue.ToString();
                    Purchase.Editor = ClassMain.UL.UserCode;
                    Purchase.EditDate = DateTime.Now;
                    Purchase.Note = textBox2.Text.Trim();
                   
                    bus.Bus_Purchase_Del(Purchase);
                    bus.Bus_Purchase_Insert(Purchase);
                    List<Bus_PurchaseItem> list = new List<Bus_PurchaseItem>();

                    for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
                    {
                        Bus_PurchaseItem item = new Bus_PurchaseItem();
                        item.SheetID = sheetid;
                        item.OrderNo = (i + 1);
                        item.VaccineCode = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        item.ProductDate  =Convert.ToDateTime( dataGridView1.Rows[i].Cells[2].Value);
                        item.BatchID = dataGridView1.Rows[i].Cells[3].Value.ToString();
                        item.Cost =Convert.ToDecimal( dataGridView1.Rows[i].Cells[4].Value);
                        item.Qty =Convert.ToInt32( dataGridView1.Rows[i].Cells[5].Value);
                        list.Add(item);
                    }
                    bus.Bus_PurchaseItem_Insert(list);

                    Alter.ShowOK("保存成功！");
                    Add();
                }

            }
            catch (Exception ex)
            {
                Alter.ShowError("保存失败！");
                //throw;
            }
        }
        private bool UICheck()
        {
            
            #region 判断有效行数是否为0
            int rows = 0;
            foreach (DataGridViewRow dr in dataGridView1.Rows)
            {
                string s = Convert.ToString(dr.Cells[0].Value);
                if (s != "")
                {
                    rows = rows + 1;
                }
            }
            if (rows == 0)
            {
                //MessageBox.Show("请填写表体信息！", ClassMain.ProgMainName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                Alter.ShowError("请填写表体信息！" );
                return false;
            }
            #endregion

            #region 判断表体信息是否填写完整
            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                DataGridViewRow dr = dataGridView1.Rows[i];
                if (Convert.ToString(dr.Cells[1].Value) == "" || Convert.ToString(dr.Cells[2].Value) == ""
                    || Convert.ToString(dr.Cells[3].Value) == "" 
                    || Convert.ToString(dr.Cells[4].Value) == "" || Convert.ToString(dr.Cells[5].Value) == "")
                {
                    Alter.ShowError("表体信息未填全！");
                    return false;
                }
                
            }


            #endregion
            return true;

        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int a = e.ColumnIndex;
            int b = e.RowIndex;

            if(dataGridView1.Columns[a].Name =="成本价")
            {
                try
                {
                    string cost = dataGridView1.Rows[b].Cells[a].Value.ToString();
                    decimal d = Convert.ToDecimal( cost);
                }
                catch (Exception ex)
                {
                    dataGridView1.Rows[b].Cells[a].Value = 0;
                    //Alter.ShowError("请检查输入数据格式");
                    //throw;
                }
            }
            if (dataGridView1.Columns[a].Name == "数量")
            {
                try
                {
                    string cost = dataGridView1.Rows[b].Cells[a].Value.ToString();
                    int d = Convert.ToInt32(cost);
                }
                catch (Exception ex)
                {
                    dataGridView1.Rows[b].Cells[a].Value = 0;
                    //Alter.ShowError("请检查输入数据格式");
                    //throw;
                }
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int a = e.ColumnIndex;
                int b = e.RowIndex;

                if (dataGridView1.Columns[a].Name == "生产日期")
                {
                    Rectangle rect = dataGridView1.GetCellDisplayRectangle(dataGridView1.CurrentCell.ColumnIndex, dataGridView1.CurrentCell.RowIndex, false);
                    dtp.Left = rect.Left;
                    dtp.Top = rect.Top;
                    dtp.Width = rect.Width;
                    dtp.Height = rect.Height;
                    dtp.Visible = true;
                }
                else
                {
                    dtp.Visible = false;
                }
            }
            catch
            {
            }
        }



    }
}
