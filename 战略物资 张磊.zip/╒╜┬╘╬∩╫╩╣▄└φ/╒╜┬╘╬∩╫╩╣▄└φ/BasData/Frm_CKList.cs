﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace 战略物资管理.BasData
{
    public partial class Frm_CKList : Form
    {
        BasBLL bll = new BasBLL();
        BusBLL bus = new BusBLL();

        public Frm_CKList()
        {
            InitializeComponent();
        }

        private void Frm_CKList_Load(object sender, EventArgs e)
        {
            BindComboBox.cmb_drop(comboBox1, bll.QueryCustomer("", ""), "CustomerCode", "Name", "--请选择客户--");
            comboBox1.SelectedIndex = 0;
            Bind();

        }
        private void Bind()
        {
            dataGridView1.AutoGenerateColumns = false;

            dataGridView1.DataSource = bus.View_Sale(textBox1.Text, dateTimePicker1.Text, Convert.ToString(comboBox1.SelectedValue)).Tables[0];

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Bind();
        }

        private void dataGridView1_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (dataGridView1.CurrentCell != null)
            {
                Frm_CKItem frm = new Frm_CKItem();
                frm.sheetid = dataGridView1.Rows[dataGridView1.CurrentCell.RowIndex].Cells[0].Value.ToString();
                frm.status = "edit";
                frm.Show();

            }
        }



    }
}
