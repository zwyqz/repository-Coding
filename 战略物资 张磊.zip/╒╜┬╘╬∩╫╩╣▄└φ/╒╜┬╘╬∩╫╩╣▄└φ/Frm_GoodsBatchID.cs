﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BLL;

namespace 战略物资管理
{
    public partial class Frm_GoodsBatchID : Form
    {
        public string goodscode = "";
        public string[] ReturnArray = new string[5];//返回值
        BasBLL bll = new BasBLL();


        public Frm_GoodsBatchID()
        {
            InitializeComponent();
        }

        private void Frm_GoodsBatchID_Load(object sender, EventArgs e)
        {
            this.dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = bll.QueryGoodsStock(goodscode).Tables[0];
        }
        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

            int intCurrentRowNumber = this.dataGridView1.CurrentCell.RowIndex;
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                string s = this.dataGridView1.Rows[intCurrentRowNumber].Cells[i].Value.ToString().Trim();
                ReturnArray[i] = s.ToString();


            }
            this.Close();


        }





    }
}
