﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TL;
using BLL;

namespace TL
{
    public partial class Frm_userlist : Form
    {
        BasBLL bll = new BasBLL();
        string usercode = "";
        public Frm_userlist()
        {
            InitializeComponent();
        }
        private void Frm_userlist_Load(object sender, EventArgs e)
        {
            bind();
        }
        private void bind()
        {
            
            DataSet ds = new DataSet();
            ds = bll.QueryUser("","");
            if (ds.Tables[0].Rows.Count <= 0)
            {
                return;
            }
            dataGridView1.DataSource = ds.Tables[0];
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            add();

        }
        private void add()
        {
            usercode = "";
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";

            //checkBox1.Checked = false;
            //checkBox2.Checked = false;
            //checkBox3.Checked = false;
            //checkBox4.Checked = false;
            //checkBox5.Checked = false;
            //checkBox6.Checked = false;
            //usercode = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.CurrentCell != null)
            {
                int rowindex = dataGridView1.CurrentCell.RowIndex;

                usercode = Convert.ToString(dataGridView1.Rows[rowindex].Cells["UserCode"].Value);
                textBox1.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["UserCode"].Value);
                textBox2.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["UserName"].Value);
                textBox3.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["PassWord"].Value);
                textBox4.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["Email"].Value);
                textBox5.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["Phone"].Value);
                textBox6.Text = Convert.ToString(dataGridView1.Rows[rowindex].Cells["Note"].Value);

                #region MyRegion
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells[3].Value) == "1")
                //{
                //    checkBox1.Checked = true;
                //}
                //else
                //{
                //    checkBox1.Checked = false;
                //}
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells["XS"].Value) == "1")
                //{
                //    checkBox2.Checked = true;
                //}
                //else
                //{
                //    checkBox2.Checked = false;
                //}
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells["KC"].Value) == "1")
                //{
                //    checkBox3.Checked = true;
                //}
                //else
                //{
                //    checkBox3.Checked = false;
                //}
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells["BB"].Value) == "1")
                //{
                //    checkBox4.Checked = true;
                //}
                //else
                //{
                //    checkBox4.Checked = false;
                //}
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells["XX"].Value) == "1")
                //{
                //    checkBox5.Checked = true;
                //}
                //else
                //{
                //    checkBox5.Checked = false;
                //}
                //if (Convert.ToString(dataGridView1.Rows[rowindex].Cells["XT"].Value) == "1")
                //{
                //    checkBox6.Checked = true;
                //}
                //else
                //{
                //    checkBox6.Checked = false;
                //}
                #endregion



            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (usercode == "")
            {
                bll.Del_User(usercode);
                bind();
                Alter.ShowOK("已删除");
            }
        }
        //save
        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox2.Text.Trim()==""
                || textBox3.Text.Trim() == "" 
                )
            {
                Alter.ShowOK("名称密码不能为空");
                return;
            }
                
            string newusercode = textBox1.Text.Trim();
            if (newusercode == "")
            {
                newusercode = bll.GetUserID("00");
                string username = textBox2.Text.Trim();
                string password = textBox3.Text.Trim();
                string newusercode1 = textBox4.Text.Trim();
                string username2 = textBox5.Text.Trim();
                string password3 = textBox6.Text.Trim();


                bll.Del_User(usercode);
                bll.Insert_User(newusercode, username, password, newusercode1, username2, password3);
                Alter.ShowOK("保存成功！");
                bind(); add();

            }
            else
            {
                string username = textBox2.Text.Trim();
                string password = textBox3.Text.Trim();
                string newusercode1 = textBox4.Text.Trim();
                string username2 = textBox5.Text.Trim();
                string password3 = textBox6.Text.Trim();

                bll.Update_User(newusercode, username, password, newusercode1, username2, password3);
                Alter.ShowOK("保存成功！");
                bind(); add();
            }
            
            
        }



    }
}
