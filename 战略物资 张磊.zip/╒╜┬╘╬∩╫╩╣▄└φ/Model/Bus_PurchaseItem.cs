using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bus_PurchaseItem
	{
		private string sheetID;
		public string SheetID
		{
			get { return sheetID; }
			set { sheetID = value; }
		}
	
		private int orderNo;
		public int OrderNo
		{
			get { return orderNo; }
			set { orderNo = value; }
		}
	
		private string vaccineCode;
		public string VaccineCode
		{
			get { return vaccineCode; }
			set { vaccineCode = value; }
		}
	
		private DateTime productDate;
		public DateTime ProductDate
		{
			get { return productDate; }
			set { productDate = value; }
		}
	
		private string batchID;
		public string BatchID
		{
			get { return batchID; }
			set { batchID = value; }
		}
        private decimal cost;
        public decimal Cost
        {
            get { return cost; }
            set { cost = value; }
        }
		private int qty;
		public int Qty
		{
			get { return qty; }
			set { qty = value; }
		}
	}
}