using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bas_Users
	{
		private string userCode;
		public string UserCode
		{
			get { return userCode; }
			set { userCode = value; }
		}
	
		private string userName;
		public string UserName
		{
			get { return userName; }
			set { userName = value; }
		}
	
		private string passWord;
		public string PassWord
		{
			get { return passWord; }
			set { passWord = value; }
		}
	
		private int del;
		public int Del
		{
			get { return del; }
			set { del = value; }
		}
	
		private string email;
		public string Email
		{
			get { return email; }
			set { email = value; }
		}
	
		private string phone;
		public string Phone
		{
			get { return phone; }
			set { phone = value; }
		}
	
		private string note;
		public string Note
		{
			get { return note; }
			set { note = value; }
		}
	}
}