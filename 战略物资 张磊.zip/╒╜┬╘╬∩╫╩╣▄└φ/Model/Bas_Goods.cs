using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bas_Goods
	{
		private string goodsCode;
		public string GoodsCode
		{
			get { return goodsCode; }
			set { goodsCode = value; }
		}
	
		private string goodsName;
		public string GoodsName
		{
			get { return goodsName; }
			set { goodsName = value; }
		}
	
		private string shortName;
		public string ShortName
		{
			get { return shortName; }
			set { shortName = value; }
		}
	
		private int effectiveMonth;
		public int EffectiveMonth
		{
			get { return effectiveMonth; }
			set { effectiveMonth = value; }
		}
	
		private string productName;
		public string ProductName
		{
			get { return productName; }
			set { productName = value; }
		}
	
		private string note;
		public string Note
		{
			get { return note; }
			set { note = value; }
		}
        private int stockLimit;
        public int StockLimit
        {
            get { return stockLimit; }
            set { stockLimit = value; }
        }

        private int stockCaps;
        public int StockCaps
        {
            get { return stockCaps; }
            set { stockCaps = value; }
        }
        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }


	}
}