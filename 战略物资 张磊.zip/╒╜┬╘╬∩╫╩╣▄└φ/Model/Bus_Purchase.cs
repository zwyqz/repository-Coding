using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bus_Purchase
	{
		private string sheetID;
		public string SheetID
		{
			get { return sheetID; }
			set { sheetID = value; }
		}
	
		private string venderCode;
		public string VenderCode
		{
			get { return venderCode; }
			set { venderCode = value; }
		}
	
		private string editor;
		public string Editor
		{
			get { return editor; }
			set { editor = value; }
		}
	
		private DateTime editDate;
		public DateTime EditDate
		{
			get { return editDate; }
			set { editDate = value; }
		}
	
		private string note;
		public string  Note
		{
            get { return note; }
            set { note = value; }
		}
	}
}