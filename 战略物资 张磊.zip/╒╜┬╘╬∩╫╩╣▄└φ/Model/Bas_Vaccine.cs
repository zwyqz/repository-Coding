using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bas_Vaccine
	{
		private string vaccineCode;
		public string VaccineCode
		{
			get { return vaccineCode; }
			set { vaccineCode = value; }
		}
	
		private string name;
		public string Name
		{
			get { return name; }
			set { name = value; }
		}
	
		private string shortName;
		public string ShortName
		{
			get { return shortName; }
			set { shortName = value; }
		}
	
		private string producterID;
		public string ProducterID
		{
			get { return producterID; }
			set { producterID = value; }
		}
	
		private string productAddress;
		public string ProductAddress
		{
			get { return productAddress; }
			set { productAddress = value; }
		}
	
		private string spec;
		public string Spec
		{
			get { return spec; }
			set { spec = value; }
		}
	
		private string contents;
		public string Contents
		{
			get { return contents; }
			set { contents = value; }
		}
	
		private string valid;
		public string Valid
		{
			get { return valid; }
			set { valid = value; }
		}
	
		private string typeName;
		public string TypeName
		{
			get { return typeName; }
			set { typeName = value; }
		}
	
		private string kindName;
		public string KindName
		{
			get { return kindName; }
			set { kindName = value; }
		}
	
		private string normalReaction;
		public string NormalReaction
		{
			get { return normalReaction; }
			set { normalReaction = value; }
		}
	
		private string abnormalReaction;
		public string AbnormalReaction
		{
			get { return abnormalReaction; }
			set { abnormalReaction = value; }
		}
	
		private string precautions;
		public string Precautions
		{
			get { return precautions; }
			set { precautions = value; }
		}
	
		private string note;
		public string Note
		{
			get { return note; }
			set { note = value; }
		}
	}
}