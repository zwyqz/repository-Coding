using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bas_Vender
	{
		private string venderCode;
		public string VenderCode
		{
			get { return venderCode; }
			set { venderCode = value; }
		}
	
		private string name;
		public string Name
		{
			get { return name; }
			set { name = value; }
		}
	
		private string shortName;
		public string ShortName
		{
			get { return shortName; }
			set { shortName = value; }
		}
	
		private string address;
		public string Address
		{
			get { return address; }
			set { address = value; }
		}
	
		private string perSen;
		public string PerSen
		{
			get { return perSen; }
			set { perSen = value; }
		}
	
		private string license;
		public string License
		{
			get { return license; }
			set { license = value; }
		}
	
		private string note;
		public string Note
		{
			get { return note; }
			set { note = value; }
		}
	}
}