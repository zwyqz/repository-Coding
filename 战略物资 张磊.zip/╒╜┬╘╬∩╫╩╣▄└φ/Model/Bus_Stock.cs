using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bus_Stock
	{
		private string vaccineCode;
		public string VaccineCode
		{
			get { return vaccineCode; }
			set { vaccineCode = value; }
		}
	
		private int qty;
		public int Qty
		{
			get { return qty; }
			set { qty = value; }
		}
	}
}