using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bus_StockBatch
	{
		private string vaccineCode;
		public string VaccineCode
		{
			get { return vaccineCode; }
			set { vaccineCode = value; }
		}
	
		private string batchID;
		public string BatchID
		{
			get { return batchID; }
			set { batchID = value; }
		}
	
		private DateTime productDate;
		public DateTime ProductDate
		{
			get { return productDate; }
			set { productDate = value; }
		}
	
		private int qty;
		public int Qty
		{
			get { return qty; }
			set { qty = value; }
		}
	}
}