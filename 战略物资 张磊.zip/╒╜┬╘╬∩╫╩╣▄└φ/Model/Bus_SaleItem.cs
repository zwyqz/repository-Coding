using System;
using System.Collections.Generic;
using System.Text;

namespace Model //�޸����ֿռ�
{
	public class Bus_SaleItem
	{
		private string sheetID;
		public string SheetID
		{
			get { return sheetID; }
			set { sheetID = value; }
		}
	
		private int orderNo;
		public int OrderNo
		{
			get { return orderNo; }
			set { orderNo = value; }
		}
	
		private string vaccineCode;
		public string VaccineCode
		{
			get { return vaccineCode; }
			set { vaccineCode = value; }
		}
	
		private string batchID;
		public string BatchID
		{
			get { return batchID; }
			set { batchID = value; }
		}
        private decimal price;
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }
		private int qty;
		public int Qty
		{
			get { return qty; }
			set { qty = value; }
		}
	}
}